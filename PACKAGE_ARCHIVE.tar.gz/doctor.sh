#!/usr/bin/env bash
# doctor.sh — 生成済みワークスペースの自己診断コマンド
set -euo pipefail

# doctor.sh 自身の版。生成物の由来記録（.devcontainer/ORIGIN の
# `version=`）と比較し、「上流が更新されている」かどうかをネットワーク無しで
# 判定するために使う。bootstrap.sh の DCB_VERSION と同じ値を持つこと
# （bootstrap.sh は curl で単体取得されうるため、この 2 ファイルは互いを参照できず、
# 値をそれぞれ持つ。リリース準備のたびに両方を揃えて更新すること。
# tests/test-origin-record.sh が一致を機械照合する）。
#
# この比較には限界がある。doctor.sh は公開リリースごとに取得し直す前提であり、
# 古い doctor.sh をそのまま使い続けると、上流がその後さらに新しくなっていても
# 「上流が更新されています」を報告できない。診断結果にもこの限界を明示する。
DCB_VERSION="v0.22.0"
ORIGIN_REL_PATH=".devcontainer/ORIGIN"

TARGET_DIR="$PWD"
STRICT="false"

# 呼び出しに使われたパスをそのまま示す。開発リポジトリでは
# packages/devcontainer-bootstrap/doctor.sh、公開配布物ではリポジトリ直下の
# ./doctor.sh に置かれるため、固定パスを書くと片方のレイアウトで解決しない。
usage() {
  cat <<EOF
usage: bash $0 [options]

options:
  --target-dir <path>   Target workspace path (default: current directory)
  --strict              Exit non-zero on warnings
  -h, --help            Show help
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --target-dir) TARGET_DIR="$2"; shift 2 ;;
    --strict) STRICT="true"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "error: unknown option: $1" >&2; usage; exit 1 ;;
  esac
done

PASS=0
WARN=0
FAIL=0

ok() { echo "[OK] $1"; PASS=$((PASS + 1)); }
warn() { echo "[WARN] $1"; WARN=$((WARN + 1)); }
ng() { echo "[FAIL] $1"; FAIL=$((FAIL + 1)); }

section() {
  echo
  echo "=== $1 ==="
}

# ファイルの sha256 を計算する。bootstrap.sh の dcb_file_sha256 と同じ実装
# （2 ファイルは互いを参照できないため複製している）。sha256sum は GNU coreutils
# 前提で macOS 既定には無い（shasum -a 256 を使う）。両方無い環境向けに openssl も試す。
dcb_file_sha256() {
  local f="$1"
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$f" | awk '{print $1}'
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$f" | awk '{print $1}'
  elif command -v openssl >/dev/null 2>&1; then
    openssl dgst -sha256 "$f" | awk '{print $NF}'
  else
    echo "error: sha256 を計算できるコマンドが見つかりません（sha256sum / shasum / openssl のいずれかが必要です）" >&2
    exit 1
  fi
}

# vX.Y.Z 形式の版を比較する。a が b より古ければ真（終了コード 0）を返す。
#
# 文字列比較にしないのは、"v0.11.0" と "v0.9.1" を文字ごとに比べると '1' < '9' で
# 前者が小さいと判定され、11 が 9 より大きいという事実と逆転するため。
# 数値化できない区分は 0 として扱う（不正な版文字列を誤って「古い」と断定しない）。
dcb_version_lt() {
  local a="${1#v}" b="${2#v}"
  local a_major a_minor a_patch b_major b_minor b_patch
  IFS='.' read -r a_major a_minor a_patch <<< "$a"
  IFS='.' read -r b_major b_minor b_patch <<< "$b"
  [[ "$a_major" =~ ^[0-9]+$ ]] || a_major=0
  [[ "$a_minor" =~ ^[0-9]+$ ]] || a_minor=0
  [[ "$a_patch" =~ ^[0-9]+$ ]] || a_patch=0
  [[ "$b_major" =~ ^[0-9]+$ ]] || b_major=0
  [[ "$b_minor" =~ ^[0-9]+$ ]] || b_minor=0
  [[ "$b_patch" =~ ^[0-9]+$ ]] || b_patch=0
  if [[ "$a_major" -lt "$b_major" ]]; then return 0; fi
  if [[ "$a_major" -gt "$b_major" ]]; then return 1; fi
  if [[ "$a_minor" -lt "$b_minor" ]]; then return 0; fi
  if [[ "$a_minor" -gt "$b_minor" ]]; then return 1; fi
  if [[ "$a_patch" -lt "$b_patch" ]]; then return 0; fi
  return 1
}

# ORIGIN の書式を検査する（行の文法と、入力の記録 input: 行）。壊れていれば ng を出して
# 1 を返す。入力の記録が無い古い ORIGIN（inputs-format 行が無い）は、行の文法だけを
# 見て通す（後方互換。診断は version= とハッシュで従来どおり成立する）。
#
# 行の文法: 空行・# 行のほかは version= / flags= / inputs-format= / input:<名前>= /
# hash:<パス>=<sha256 の 64 桁> / accepted:<パス>=<sha256 の 64 桁>（bootstrap.sh --accept が
# 書く取り込み済みの記録）/ owned:<パス>=<値> / pending:<パス>=<値>（bootstrap.sh が書く、
# プロジェクト所有の印と、.dcb-new の取り込み待ちの印。値は読まない）のどれかであること。読み飛ばして黙って通さない。
check_origin_format() {
  local origin_file="$1" line bad="" v val mode playbook source lang l_rest
  # 最終行が改行で終わっていなくても検査する。
  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ -n "$line" ]] || continue
    case "$line" in
      '#'*) ;;
      version=*|flags=*|inputs-format=*) ;;
      input:project-name=*|input:languages=*|input:base-image-mode=*|input:base-image=*|input:manage-gitignore=*|input:gitignore-targets=*|input:playbook=*|input:playbook-source=*|input:playbook-ref=*) ;;
      input:*) bad="$bad [認識できない入力の行: ${line%%=*}]" ;;
      hash:?*=*)
        # sha256 に = は入らないが、パスには入りうる。最後の = で区切る。
        val="${line##*=}"
        if ! [[ "$val" =~ ^[0-9a-f]{64}$ ]] || [[ -z "${line#hash:}" || "${line#hash:}" == "=$val" ]]; then bad="$bad [hash の行が不正: ${line%=*}]"; fi
        ;;
      accepted:?*=*)
        # hash: の行と同じ形（パス + 最後の = + sha256 の 64 桁）。
        val="${line##*=}"
        if ! [[ "$val" =~ ^[0-9a-f]{64}$ ]] || [[ -z "${line#accepted:}" || "${line#accepted:}" == "=$val" ]]; then bad="$bad [accepted の行が不正: ${line%=*}]"; fi
        ;;
      owned:?*=*|pending:?*=*) ;;
      *) bad="$bad [認識できない行: $line]" ;;
    esac
    # 値の中の % は %25 / %0A / %0D だけを許す（書き手の符号化と対）。
    case "$line" in
      input:*=*)
        v="${line#*=}"
        v="${v//%25/}"
        v="${v//%0A/}"
        v="${v//%0D/}"
        if [[ "$v" == *%* ]]; then bad="$bad [不正な % の並び: ${line%%=*}]"; fi
        ;;
    esac
  done < "$origin_file"

  # input: の行があるのに inputs-format が無い記録は、旧形式ではなく壊れた新形式。
  if awk '/^input:/ { f = 1 } END { exit !f }' "$origin_file" \
    && ! awk '/^inputs-format=/ { f = 1 } END { exit !f }' "$origin_file"; then
    bad="$bad [input: の行があるのに inputs-format= の行が無い]"
  fi

  # 同じ input: のキーが 2 回以上あれば不正（どちらが効くかを読み手が決めてしまう）。
  v="$(awk '/^input:/ { k = $0; sub(/=.*/, "", k); if (seen[k]++ == 1) printf "%s ", k }' "$origin_file")"
  if [[ -n "$v" ]]; then
    for lang in $v; do bad="$bad [入力の行が重複: $lang]"; done
  fi

  if awk '/^inputs-format=/ { f = 1 } END { exit !f }' "$origin_file"; then
    if [[ "$(origin_get "$origin_file" inputs-format)" != "1" ]]; then
      warn "origin inputs-format is not 1 ($ORIGIN_REL_PATH): この doctor.sh が知らない書式の入力記録なので、入力の検査を省きます（取得し直した最新の doctor.sh を使ってください）"
    else
      # 新しい形式（inputs-format=1）では version= と flags= が必須（空の値は許す）。
      awk '/^version=/ { f = 1 } END { exit !f }' "$origin_file" || bad="$bad [version= の行が無い]"
      awk '/^flags=/ { f = 1 } END { exit !f }' "$origin_file" || bad="$bad [flags= の行が無い]"
      v="$(origin_get "$origin_file" input:project-name)" || v=""
      [[ -n "$v" ]] || bad="$bad [input:project-name が無い、または空]"
      v="$(origin_get "$origin_file" input:languages)" || v=""
      if [[ -z "$v" ]]; then
        bad="$bad [input:languages が無い、または空]"
      else
        l_rest="$v,"
        while [[ -n "$l_rest" ]]; do
          lang="${l_rest%%,*}"
          l_rest="${l_rest#*,}"
          case "$lang" in
            node|go|python|php|rust|ruby) ;;
            *) bad="$bad [input:languages に未対応または空の値: '$lang']" ;;
          esac
        done
      fi
      mode="$(origin_get "$origin_file" input:base-image-mode)" || mode=""
      case "$mode" in
        auto)
          # bootstrap.sh は auto でも観測記録として必ず書く。
          origin_get "$origin_file" input:base-image >/dev/null || bad="$bad [input:base-image が無い]"
          ;;
        override)
          v="$(origin_get "$origin_file" input:base-image)" || v=""
          [[ -n "$v" ]] || bad="$bad [input:base-image-mode=override なのに input:base-image が無い、または空]"
          ;;
        *) bad="$bad [input:base-image-mode が auto / override ではない]" ;;
      esac
      v="$(origin_get "$origin_file" input:manage-gitignore)" || v=""
      case "$v" in true|false) ;; *) bad="$bad [input:manage-gitignore が true / false ではない]" ;; esac
      origin_get "$origin_file" input:gitignore-targets >/dev/null || bad="$bad [input:gitignore-targets が無い]"
      playbook="$(origin_get "$origin_file" input:playbook)" || playbook=""
      case "$playbook" in
        none) ;;
        installed)
          source="$(origin_get "$origin_file" input:playbook-source)" || source=""
          case "$source" in
            tag|url)
              # 記録しない場合（資格情報を含みうる URL）がある url は ref 無しを許す。tag は必須。
              if [[ "$source" == "tag" ]]; then
                v="$(origin_get "$origin_file" input:playbook-ref)" || v=""
                [[ -n "$v" ]] || bad="$bad [input:playbook-source=tag なのに input:playbook-ref が無い、または空]"
              fi
              ;;
            local|adjacent) ;;
            *) bad="$bad [input:playbook-source が tag / url / local / adjacent ではない]" ;;
          esac
          ;;
        *) bad="$bad [input:playbook が installed / none ではない]" ;;
      esac
    fi
  fi

  if [[ -n "$bad" ]]; then
    ng "origin record malformed ($ORIGIN_REL_PATH):$bad。乖離を診断できません"
    return 1
  fi
  return 0
}

# ORIGIN から key の値を復号して出す。無ければ 1 を返す（空の値は 0 で空を出す）。
origin_get() {
  local file="$1" key="$2" raw v pct='%' nl=$'\n' cr=$'\r'
  raw="$(awk -v k="$key=" 'index($0, k) == 1 { print substr($0, length(k) + 1); found = 1; exit } END { exit !found }' "$file")" || return 1
  v="${raw//%0A/$nl}"
  v="${v//%0D/$cr}"
  v="${v//%25/$pct}"
  printf '%s' "$v"
}

# 生成物の由来（.devcontainer/ORIGIN）を診断する。ネットワークは
# 使わない。上流の更新有無は doctor.sh 自身に埋め込んだ DCB_VERSION とだけ比べる
# （このファイル冒頭のコメント参照）。
#
# 記録が無い生成先・記録が壊れている生成先は、診断できないことを明示して報告する。
# 「検査が成立しないことを合格にしない」ため、この場合に ok() は呼ばない。
check_origin_record() {
  local origin_file="$TARGET_DIR/$ORIGIN_REL_PATH"

  if [[ ! -f "$origin_file" ]]; then
    warn "origin record missing ($ORIGIN_REL_PATH): 生成物の由来が記録されていないため乖離を診断できません（この生成先が本機能より前に作られたか、記録が削除された可能性があります。記録の無い生成先への遡及はできません）"
    return 0
  fi

  if [[ ! -r "$origin_file" ]]; then
    ng "origin record unreadable ($ORIGIN_REL_PATH): 読み取れないため乖離を診断できません"
    return 0
  fi

  # `sed ... | head -1` にしない。version= が複数行あるとき sed が全行を出し切る前に
  # head が読み取りを打ち切り、pipefail 下で SIGPIPE により判定が反転しうる
  # （scripts/check-shell-portability.sh が検出する）。awk 単体で最初の一致だけを取る。
  local origin_version
  origin_version="$(awk '/^version=/ { sub(/^version=/, ""); print; exit }' "$origin_file")"
  if [[ -z "$origin_version" ]]; then
    ng "origin record malformed ($ORIGIN_REL_PATH): version= 行を読み取れません。乖離を診断できません"
    return 0
  fi
  # 値が vX.Y.Z 形式であることを比較の前に検証する。dcb_version_lt は数値化できない
  # 区分を 0 として扱うため、検証せずに渡すと "v0.11.0garbage" のような壊れた値でも
  # 版番号の一部（0.11.0）だけを読んで比較が成立してしまい、壊れた記録を合格にする
  # （実測）。
  if ! [[ "$origin_version" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    ng "origin record malformed ($ORIGIN_REL_PATH): version の値が vX.Y.Z 形式ではありません（recorded=$origin_version）。乖離を診断できません"
    return 0
  fi

  if dcb_version_lt "$origin_version" "$DCB_VERSION"; then
    warn "origin version is older than doctor.sh: recorded=$origin_version self=$DCB_VERSION（上流が更新されています。この判定は doctor.sh 自身の版が基準なので、取得し直した最新の doctor.sh でなければ検知できません）"
  else
    ok "origin version matches or is newer than doctor.sh: recorded=$origin_version self=$DCB_VERSION"
  fi

  check_origin_format "$origin_file" || return 0

  local hash_count=0 unchanged_count=0 accepted_count=0 owned_count=0 stale_pending="" stale_pending_count=0 changed="" missing="" line rel recorded_hash actual_hash accepted_hash
  while IFS= read -r line; do
    [[ -n "$line" ]] || continue
    rel="${line#hash:}"
    rel="${rel%=*}"
    recorded_hash="${line##*=}"
    [[ -n "$rel" && -n "$recorded_hash" ]] || continue
    hash_count=$((hash_count + 1))
    if [[ ! -f "$TARGET_DIR/$rel" ]]; then
      missing="$missing $rel"
      continue
    fi
    actual_hash="$(dcb_file_sha256 "$TARGET_DIR/$rel")"
    if [[ "$actual_hash" == "$recorded_hash" ]]; then
      unchanged_count=$((unchanged_count + 1))
      # 現物が記録と一致するのに pending: が残っている: 取り込む差分は無いが記録が古い。
      if awk -v k="pending:$rel=" 'index($0, k) == 1 { f = 1 } END { exit !f }' "$origin_file"; then
        stale_pending="$stale_pending $rel"
        stale_pending_count=$((stale_pending_count + 1))
      fi
    else
      # 手を入れた現物でも、取り込み済みとして記録した（accepted:）内容と一致すれば乖離としない。
      # その後さらに手を入れれば accepted とも一致せず、changed に戻る。
      # プロジェクト所有（owned:）のファイルは、日常的に編集するものなので、手を入れただけでは
      # 乖離としない。ただし .dcb-new の取り込み待ち（pending:）があれば乖離のまま。
      accepted_hash="$(awk -v k="accepted:$rel=" 'index($0, k) == 1 { print substr($0, length(k) + 1); exit }' "$origin_file")"
      if awk -v k="pending:$rel=" 'index($0, k) == 1 { f = 1 } END { exit !f }' "$origin_file"; then
        changed="$changed $rel"
      elif [[ -n "$accepted_hash" && "$actual_hash" == "$accepted_hash" ]]; then
        accepted_count=$((accepted_count + 1))
      elif awk -v k="owned:$rel=" 'index($0, k) == 1 { f = 1 } END { exit !f }' "$origin_file"; then
        owned_count=$((owned_count + 1))
      else
        changed="$changed $rel"
      fi
    fi
  done < <(grep '^hash:' "$origin_file" || true)

  if [[ "$hash_count" -eq 0 ]]; then
    warn "origin record has no per-file hash ($ORIGIN_REL_PATH): 生成物ごとの記録が無いため変化を診断できません"
    return 0
  fi

  if [[ -n "$changed" ]]; then
    ng "changed since generation:$changed（取り込みを済ませた変更なら、bootstrap.sh --accept <path> で取り込み済みとして記録できます。そうでなければ、変更を戻すか .dcb-new を取り込んでください）"
  fi
  if [[ -n "$missing" ]]; then
    ng "recorded in origin but missing:$missing"
  fi
  if [[ "$accepted_count" -gt 0 ]]; then
    ok "accepted as merged ($accepted_count file(s)): 取り込み済みとして記録した内容と一致しています"
  fi
  if [[ "$stale_pending_count" -gt 0 ]]; then
    warn "stale pending record ($stale_pending_count file(s)):$stale_pending（取り込み待ちの記録（pending:）が残っていますが、現物は新しい版と一致しています。bootstrap.sh --accept <path> か --upgrade で外してください）"
  fi
  if [[ "$owned_count" -gt 0 ]]; then
    ok "edited project-owned file(s) ($owned_count file(s)): プロジェクトが所有・編集するファイルなので、生成時からの変化を乖離として扱いません"
  fi
  if [[ -z "$changed" && -z "$missing" ]]; then
    ok "unchanged since generation ($unchanged_count file(s))"
  fi
}

# --upgrade が置いた *.dcb-new（手を入れたファイルの隣に置く新しい版）が残っていれば
# WARN で報告する。探し方は bootstrap.sh の upgrade_collect_leftover と揃える
# （.git と node_modules は除外し、シンボリックリンクはたどらない）。
check_dcb_new_leftover() {
  local found err_file find_rc=0 find_err=""
  err_file="$(mktemp "${TMPDIR:-/tmp}/dcb-doctor-find.XXXXXX")"
  found="$(find "$TARGET_DIR" \( -name .git -o -name node_modules \) -prune -o -name '*.dcb-new' -print 2>"$err_file")" || find_rc=$?
  found="$(printf '%s\n' "$found" | sed '/^$/d' | sort)"
  find_err="$(head -3 "$err_file")"
  rm -f "$err_file"
  if [[ "$find_rc" -ne 0 ]]; then
    warn "*.dcb-new を一部探索できませんでした（find が終了コード $find_rc）: ${find_err:-理由不明}"
  fi
  if [[ -z "$found" ]]; then
    [[ "$find_rc" -eq 0 ]] || return 0
    ok "no *.dcb-new left behind"
    return 0
  fi
  warn "*.dcb-new が残っています（--upgrade が置いた新しい版です）:"
  printf '%s\n' "$found" | sed 's|^|  - |'
  echo "  取り込み方: 元のファイルと .dcb-new の中身を見比べ、必要な差分を手で混ぜてから、.dcb-new を消してください（自動では混ぜません）。"
}

require_file() {
  local f="$1"
  if [[ -f "$TARGET_DIR/$f" ]]; then
    ok "$f exists"
  else
    ng "$f missing"
  fi
}

require_exec() {
  local f="$1"
  if [[ -x "$TARGET_DIR/$f" ]]; then
    ok "$f executable"
  else
    warn "$f not executable"
  fi
}

section "Static structure"
require_file ".devcontainer/devcontainer.json"
require_file ".env.example"
require_file "scripts/on-attach.sh"
require_file "scripts/fix-mount-owner.sh"
require_file "scripts/post-rebuild-check.sh"
require_file "scripts/verify.sh"
require_file "scripts/acceptance.sh"
require_file "scripts/loop-gate.sh"
# verify.sh は不在なら VERIFY_FAIL で止まる（検査が成立していないことを合格に
# しないため）。実在を静的構造として見ておかないと、原因が「機密混入検査の欠落」
# だと分かるのが verify を回した後になる。
require_file "scripts/check-no-secrets.sh"

# JSONC（コメント付きの JSON）から、コメント（// と /* */）を除いて標準出力へ出す。
# 文字列リテラルの中の // や /* は残す（例: "https://example.com"）。--with-codex の
# devcontainer.json は説明のコメントを持つ。doctor.sh は単体で取得されうるため、
# この関数は他のファイルを参照せずここに持つ。GNU 拡張に頼らない（perl を使う）。
jsonc_strip() {
  perl -0777 -pe 's{("(?:\\.|[^"\\])*")|//[^\n]*|/\*.*?\*/}{defined $1 ? $1 : ""}gse' "$1"
}

if [[ -f "$TARGET_DIR/.devcontainer/devcontainer.json" ]]; then
  if jsonc_strip "$TARGET_DIR/.devcontainer/devcontainer.json" 2>/dev/null | jq . >/dev/null 2>&1; then
    ok "devcontainer.json valid JSON"
  else
    ng "devcontainer.json invalid JSON"
  fi

  # 資格情報のホスト注入は廃止した。remoteEnv に ${localEnv:...} が現れることは、
  # ホスト OS の環境変数をコンテナへ流し込む経路が復活したことを意味する。
  # 作業ディレクトリの受け渡し（localWorkspaceFolder）は localEnv ではないため対象外。
  # shellcheck disable=SC2016
  if grep -q '\${localEnv:' "$TARGET_DIR/.devcontainer/devcontainer.json"; then
    ng "secrets policy: localEnv reference found (ホスト資格情報の注入経路)"
  else
    ok "secrets policy: no localEnv reference"
  fi

  # compose 配線の検査。dockerComposeFile が無い旧 image ベース構成は検査しない（後方互換）。
  compose_files="$(jsonc_strip "$TARGET_DIR/.devcontainer/devcontainer.json" 2>/dev/null \
    | jq -r '.dockerComposeFile // empty | if type == "array" then .[] else . end' 2>/dev/null || true)"
  if [[ -n "$compose_files" ]]; then
    while IFS= read -r compose_file; do
      [[ -n "$compose_file" ]] || continue
      case "$compose_file" in
        # 絶対パスは devcontainer.json からの相対解決を行わずそのまま検査する
        /*)
          if [[ -f "$compose_file" ]]; then
            ok "dockerComposeFile exists: $compose_file"
          else
            ng "dockerComposeFile missing: $compose_file"
          fi
          ;;
        *) require_file ".devcontainer/$compose_file" ;;
      esac
    done <<< "$compose_files"
  fi
fi

section "Script checks"
if [[ -f "$TARGET_DIR/scripts/on-attach.sh" ]]; then
  if bash -n "$TARGET_DIR/scripts/on-attach.sh"; then
    ok "on-attach.sh syntax OK"
  else
    ng "on-attach.sh syntax NG"
  fi
  require_exec "scripts/on-attach.sh"
fi

if [[ -f "$TARGET_DIR/scripts/fix-mount-owner.sh" ]]; then
  if bash -n "$TARGET_DIR/scripts/fix-mount-owner.sh"; then
    ok "fix-mount-owner.sh syntax OK"
  else
    ng "fix-mount-owner.sh syntax NG"
  fi
  require_exec "scripts/fix-mount-owner.sh"
fi

if [[ -f "$TARGET_DIR/scripts/post-rebuild-check.sh" ]]; then
  if bash -n "$TARGET_DIR/scripts/post-rebuild-check.sh"; then
    ok "post-rebuild-check.sh syntax OK"
  else
    ng "post-rebuild-check.sh syntax NG"
  fi
  require_exec "scripts/post-rebuild-check.sh"
fi

# ループコーディングの機構（受け入れゲート）。単体で動作する前提で検査する。
# acceptance-remote.sh（外部層）は --with-aws / --with-gcp を選んだ構成にだけ存在する
# ため、実在検査（require_file）は張らず、あるときだけ構文と実行ビットを見る。
# 生成後にプロジェクトが検査を書き足すファイルなので、構文の検査対象へ入れる価値がある。
# 他の 4 本は無条件に配られるので上で require_file 済みで、ここでは中身を見る。
for loop_script in verify.sh acceptance.sh loop-gate.sh check-no-secrets.sh acceptance-remote.sh; do
  if [[ -f "$TARGET_DIR/scripts/$loop_script" ]]; then
    if bash -n "$TARGET_DIR/scripts/$loop_script"; then
      ok "$loop_script syntax OK"
    else
      ng "$loop_script syntax NG"
    fi
    require_exec "scripts/$loop_script"
  fi
done

# 配布された検査 4 本（衛生検査）が、acceptance.sh から参照されているかを見る。
# 置かれただけで呼ばれない検査は効かない。acceptance.sh はプロジェクトの所有物なので
# --upgrade は配線を書き換えられない。そのため WARN で知らせる（FAIL にはしない）。
# 参照の判定はファイル名の出現で行う。コメントに書いたファイル名も参照に数えるので、
# 意図して呼ばない検査は、ファイル名と理由をコメントで書けば WARN が出ない。
# doctor.sh は単体で取得されうるため、この 4 本の一覧は bootstrap.sh を参照せずここに持つ
# （bootstrap.sh の hygiene_check_rel_paths と同じ内容。一致は tests/test-hygiene-wiring.sh が
# 機械照合する）。
HYGIENE_CHECKS="check-control-chars.sh check-table-breaks.sh check-doc-links.sh check-shell-portability.sh"

check_hygiene_wiring() {
  local acceptance="$TARGET_DIR/scripts/acceptance.sh" name present=0 unwired="" unwired_count=0
  # acceptance.sh が無いときは判定しない（実在は静的構造の検査が FAIL にする）。
  [[ -f "$acceptance" ]] || return 0
  for name in $HYGIENE_CHECKS; do
    [[ -f "$TARGET_DIR/scripts/$name" ]] || continue
    present=$((present + 1))
    if ! grep -F -- "$name" "$acceptance" >/dev/null 2>&1; then
      unwired="$unwired $name"
      unwired_count=$((unwired_count + 1))
    fi
  done
  [[ "$present" -gt 0 ]] || return 0
  if [[ "$unwired_count" -eq 0 ]]; then
    ok "hygiene checks are referenced from scripts/acceptance.sh ($present file(s))"
    return 0
  fi
  warn "hygiene checks not wired into scripts/acceptance.sh ($unwired_count of $present):$unwired（置かれただけで、acceptance.sh から呼ばれていません）"
  echo "  配線の例（scripts/acceptance.sh の、ran_any の判定の手前）:"
  for name in $unwired; do
    echo "    bash scripts/$name"
  done
  echo "  意図して呼ばない検査は、acceptance.sh にファイル名と理由をコメントで書くと、この WARN は出ません。"
}

section "Hygiene checks wiring"
check_hygiene_wiring

section "Generation origin"
check_origin_record
check_dcb_new_leftover

section "Runtime command availability"
for cmd in bash jq perl gh; do
  if command -v "$cmd" >/dev/null 2>&1; then
    ok "$cmd command available"
  else
    warn "$cmd command missing"
  fi
done

# devcontainer.json の features から設定済み言語を動的に検出する
check_runtime_languages() {
  local devcontainer_json="$TARGET_DIR/.devcontainer/devcontainer.json"
  if [[ ! -f "$devcontainer_json" ]]; then
    warn "devcontainer.json not found for language detection"
    return
  fi

  # features から言語ランタイム（node, go, python, php, rust, ruby）を抽出する。
  # feature キー名とランタイムコマンド名は原則一致するが、rust だけは feature が
  # rust なのに実行ファイルが cargo/rustc に分かれ「rust」コマンドは存在しない。
  # bootstrap.sh の runtime_check_cmd と同じ写像で検査コマンドを解決する。
  for lang in node go python php rust ruby; do
    if grep -q "\"ghcr.io/devcontainers/features/$lang:1\"" "$devcontainer_json" 2>/dev/null; then
      local cmd
      case "$lang" in
        rust) cmd="cargo" ;;
        *)    cmd="$lang" ;;
      esac
      if command -v "$cmd" >/dev/null 2>&1; then
        ok "$lang command available ($cmd)"
      else
        warn "$lang command missing ($cmd)"
      fi
    fi
  done
}

check_runtime_languages

# devcontainer.json の features から配線済みの cloud ツールを検出し、対応 CLI を確認する。
# feature キーと CLI 名は 1 対 1 でない（gcp は google-cloud-cli feature → gcloud）。
check_with_features() {
  local devcontainer_json="$TARGET_DIR/.devcontainer/devcontainer.json"
  [[ -f "$devcontainer_json" ]] || return
  # "feature-path:cli-name" の対で検査する。feature path は bootstrap.sh の
  # with_feature_path と一致させる（aws/terraform は devcontainers 名前空間、gcp は
  # 外部 dhoeric）。bash 3.2 互換のため連想配列は使わない。
  local pair feat cli
  for pair in \
    "devcontainers/features/aws-cli:aws" \
    "dhoeric/features/google-cloud-cli:gcloud" \
    "devcontainers/features/terraform:terraform"; do
    feat="${pair%:*}"
    cli="${pair##*:}"
    if grep -q "\"ghcr.io/$feat:1\"" "$devcontainer_json" 2>/dev/null; then
      if command -v "$cli" >/dev/null 2>&1; then
        ok "$cli command available"
      else
        warn "$cli command missing"
      fi
    fi
  done
}

check_with_features

if grep -q 'docker-outside-of-docker' "$TARGET_DIR/.devcontainer/devcontainer.json" 2>/dev/null; then
  if command -v docker >/dev/null 2>&1; then
    ok "docker command available"
  else
    warn "docker command missing"
  fi
fi

echo
echo "Summary: PASS=$PASS WARN=$WARN FAIL=$FAIL"

if [[ "$FAIL" -gt 0 ]]; then
  exit 1
fi

if [[ "$STRICT" == "true" && "$WARN" -gt 0 ]]; then
  exit 2
fi

exit 0
