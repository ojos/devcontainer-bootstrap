# devcontainer-bootstrap Release Notes

新世代（2026-07-17 リポジトリ再作成後）のリリースノートです。旧世代（〜v0.3.1）は開発リポジトリの `docs/archive/release-notes-devcontainer-bootstrap.md` にあります。

> このファイルは公開リポジトリへ `CHANGELOG.md` として配布されます。配布先には `docs/` 階層が存在しないため、リポジトリ内の相対リンクを書かないでください（配布先で解決できないリンクになります）。
>
> 同じ理由で、issue 参照は `ojos/ai-packages-dev#NNN` の形で書いてください。裸の `#NNN` は GitHub のオートリンクが**配布先リポジトリの issue** として解決するため、配布後は存在しない issue や無関係な issue を指します。

## v0.24.0

### Summary
- **生成する `scripts/install-ai-tools.sh` が、claude・gemini にも版の下限を持たせた**（ojos/ai-packages-dev#684）。下限より古いものが既に入っていれば npm の `@latest` で入れ替え（CLI の名前・今の版・下限を出す）、入れたあとも下限未満なら非 0 で止まる。下限は claude 2.1.314（`doctor.sh` の `CLAUDE_MIN_VERSION` と同じ値。テストで照合する）、gemini 0.64.0。codex（0.156.0）が持っていた版の比較を共通の関数（`ai_cli_version_is_old`・`ai_cli_version`・`install_if_missing` の第 3 引数）に一般化し、3 つで共有する。
- **agy の導入が、配布元のインストーラ（取得して実行する形）をやめ、本体の SHA-512 を自分で照合してから置く形になった**（ojos/ai-packages-dev#684）。プラットフォームを配布元のインストーラと同じ判定で決め（linux の amd64・arm64 とそれぞれの musl 版、darwin。表に無いものは理由を出して非 0）、マニフェストを取り、本体を落として SHA-512 を照合し、`~/.local/bin/agy` へ置いて `agy install` を呼ぶ。マニフェストは `jq` で JSON として読み、置く前に本体の `--version` も確かめる。照合が通らない・マニフェストを読めない・キーが欠けている・マニフェストや本体の版が下限 1.3.4 未満のときは、理由を出して何も置かずに非 0。既にある agy が下限未満なら同じ手順で入れ替え、下限以上なら何もしない。雛形に、遠くのスクリプトを実行する行は残らない。
- **第二意見の既定のエンジンが gemini から codex に変わったのに合わせ、生成する `.env.example` のエンジンの欄の説明を直した**（ojos/ai-packages-dev#682）。「空なら gemini」を「空なら codex」に改めた（antigravity だけの構成では、codex を導入しないので、使うエンジンを記入しておくよう述べる）。**`--with-gemini` だけの構成でも `SECOND_OPINION_ENGINE` の欄を出し、`gemini` を記入するようにした。** これまでは antigravity か codex を選んだときだけ欄を出していたため、gemini だけで生成したプロジェクトは既定の変更の影響をそのまま受けた。`--second-opinion-engine` も、`--with-gemini` だけの構成で受け付ける。`second-opinion-review.sh` の既定の変更そのものは ai-playbook v0.13.0 が持つ。
- **エージェントに任意のコードを実行させうる git の設定を検出する `scripts/check-git-config.sh` を足した**（ojos/ai-packages-dev#671）。`core.fsmonitor`・`core.hooksPath`・`core.sshCommand`・`credential.helper`・`gpg.program`・`diff.external`・diff / filter / merge のドライバ・`remote.<名前>.uploadpack` など、git の普段の操作でコマンドを実行させうるキーを、local と worktree の設定（取り込んだ先を含む）から読み取りだけで検出する。SessionStart のフックと doctor では、仕込まれた値が会話の文脈に入らないよう、キーの種類と件数だけを出す。設定は NUL 区切りで読む（改行を含む値を読み違えない）。git を呼んだ瞬間にコマンドを実行させる攻撃（サンドボックスも承認も通らない）への備え。`--with-claude` で生成する `.claude/settings.json` の SessionStart と、`doctor.sh`（WARN）から呼ぶ。拒否はしない。正当な設定は根の `.git-config-allow` に `キー=値` で書いてコミットすると黙る（読むのはコミット済みの中身だけ）。
- **`loop-gate.sh` が、エージェントの設定・フックに触れる変更を一覧に出す**（ojos/ai-packages-dev#671）。`.claude/`・`.mcp.json`・`.github/workflows/`・`.githooks/`・`.husky/`・`.git-config-allow`・`.gitattributes`（どの階層も）・`.gitmodules`・`.devcontainer/`・`.vscode/`・フックの本体のスクリプトに当たるパスを（改名は移動元も）出力し、環境変数 `SECOND_OPINION_AGENT_CONFIG_PATHS` で第二意見へ渡す。判定と終了コードは変えない。
- **生成する `.claude/settings.json` に、権限を締める側の設定を 2 つ足した**（ojos/ai-packages-dev#672）。`permissions.blockWritesOutsideWorkingDirectories: true`（作業ディレクトリの外への書き込みを止める）と、確認フック（`confirm-merge-hook.sh`）の hook への `"onFailure": "block"`（フックが失敗したとき通さず止める）。セッション協調フックには付けない（台帳は fail-open が規範）。許可リストは引き続き持たない。
- **`doctor.sh` が Claude Code の版を検査する**（ojos/ai-packages-dev#672）。対象の `.claude/settings.json` がこの設定を持ち、`claude` が PATH にあるときだけ、`claude --version` を下限 2.1.314 と比べ、古ければ WARN（`blockWritesOutsideWorkingDirectories` が、エラーも警告も出ずに黙って無視される）。版を読めないときも WARN。設定を持たない対象と、`claude` が無い環境では検査しない。
- **`--with-claude` のとき、共通規範を常時の規則と条件付きの規則に分けて生成し、`CLAUDE.md` から全文の取り込みを外した**（ojos/ai-packages-dev#678）。今までは `CLAUDE.md` が `@.ai-playbook/shared-ai-rules.md` で全文（約 50KB）を毎セッションの文脈へ載せていた。正本の見出しの印（`<!-- claude-rules: name=<題> paths=<glob>,<glob> -->`。ai-playbook v0.13.0 が付ける）に従い、印の無い範囲を `.claude/rules/ai-playbook.md`（`paths:` なし＝起動時に必ず載る）へ、印の範囲を `.claude/rules/ai-playbook-<題>.md`（`paths:` 付き。一致するファイルに触れたときだけ載る。`@` の取り込みは入れない）へ生成する。正本の行は印の行を除いて変えずに写し、各ファイルの先頭に、生成物である旨と相対リンクの基準を述べる断りを足す。`CLAUDE.md` は ai-playbook の `templates/claude-entry-imports-rules.md`（`@.github/project-ai-rules.md` だけを取り込む版）を使う。`--with-claude` なしの `CLAUDE.md` と `AGENTS.md`・`copilot-instructions.md` は変えない。生成物は ORIGIN のハッシュに乗り、`--upgrade` では手を入れていなければ作り直し、手を入れていれば `.dcb-new` を置く。DCB が作っていない同名のファイルは上書きしない。
- **生成の処理だけを行う入口 `--render-claude-rules <正本> <出力ディレクトリ>` を足した**（ojos/ai-packages-dev#678）。`CLAUDE.md` を手で書くプロジェクトが、規則を正本から作り直すために使う。印の書式の誤りや、同じ題で `paths` が食い違うときは、何も書かずに非 0 で止まる。出力先に、生成する名前と同名の手書きの規則（生成物の断りが無いファイル）・シンボリックリンク・ファイルでないもの・読めないものがあるときも、上書きせず、その名前を出して何も書かずに非 0 で止まる（ojos/ai-packages-dev#680）。
- **`scripts/check-doc-links.sh` が、生成した規則（`.claude/rules/ai-playbook*.md`）を走査しない**（ojos/ai-packages-dev#678）。生成した規則の本文は正本の行そのままで、相対リンクは `.ai-playbook/` からの相対のまま残るため、そこからの相対では解決できない。同じリンクは正本が持ち、正本は走査される。生成物かどうかは先頭の断りの行で見分け、断りの無い同名の規則は手で書いたものとして走査する。集計の「除外」の件数に数える。
- **この版が要求する ai-playbook は変わらない**。ai-playbook が `templates/claude-entry-imports-rules.md` を持たない古い版では、分割をせず従来どおり全文を取り込む。分割を使うには、ai-playbook v0.13.0 以降（`templates/claude-entry-imports-rules.md` と印を持つ版）を指定する。勧める ai-playbook は v0.13.0。

### 移行
- `scripts/install-ai-tools.sh` は `bootstrap.sh --upgrade` で追従する（手を入れていなければ置き換わる）。次にコンテナを作る（または `bash scripts/install-ai-tools.sh` を再実行する）とき、下限より古い claude・gemini・agy が入れ替わる。agy の導入先は従来どおり `~/.local/bin/agy`。
- **第二意見のエンジンを指定していない（`.env` の `SECOND_OPINION_ENGINE` が空か無い）プロジェクトだけが対象です。** `.env` で明示した値はそのまま使われます。**以前の DCB で `--with-gemini` だけを選んで生成したプロジェクトは、欄が無いので対象です。** ai-playbook の新しい版を取り込むと codex を使おうとし、使えなければ案内を出して止まります。gemini を使い続けるには、`.env` に `SECOND_OPINION_ENGINE=gemini` を書きます（この版の `--upgrade` で `.env.example` に欄が入りますが、`.env` へは写されないので、手で書き足します）。
- 既にある `.claude/settings.json` は、衝突の扱い（既定は温存）に従って書き換えない。SessionStart の配線が欲しければ、`bash "$CLAUDE_PROJECT_DIR/scripts/check-git-config.sh" --hook` を手で足す。
  `permissions.blockWritesOutsideWorkingDirectories: true` と、確認フックの hook への `"onFailure": "block"` も、同様に手で足す。
- husky などで `core.hooksPath` を使っているプロジェクトは、`doctor.sh` が WARN を出すようになる。`.git-config-allow` に `core.hooksPath=<値>` を書いてコミットすると黙る。
- 第二意見の依頼文へ一覧を添えるのは、ai-playbook v0.13.0 の雛形の `second-opinion-review.sh` から。古い雛形と組み合わせても、一覧は loop-gate の出力に出る（依頼文に添えられないだけ）。
- **`--upgrade` で手を入れた `CLAUDE.md` は古いまま残る。** 新しい版は隣の `CLAUDE.md.dcb-new` に置かれる。古い `CLAUDE.md` は `@.ai-playbook/shared-ai-rules.md` で全文を取り込み続けるので、新しく生成された `.claude/rules/ai-playbook*.md` と二重に載る（規範の全文と、同じ内容の規則が両方文脈に入る）。取り込み方: `CLAUDE.md` の `@.ai-playbook/shared-ai-rules.md` の行と、それを説明する文を外し（`CLAUDE.md.dcb-new` の「規範の取り込み（Claude Code）」の節に差し替える）、`CLAUDE.md.dcb-new` を消してから `bash bootstrap.sh --accept CLAUDE.md` で取り込み済みにする。`@.github/project-ai-rules.md` の行は残す。
- 既存の出力先は `scripts/check-doc-links.sh` を `--upgrade` で更新して追従する（手を入れていなければ置き換わる）。
- **正本から題が消えた・変わったとき、古い `.claude/rules/ai-playbook-<題>.md` は残る。** `--upgrade` は生成しなくなったファイルを消さず、「no longer generated (not deleted)」と報告するだけにしている。残すと、その `paths:` に一致するファイルに触れるたびに載り続ける。報告に出た規則は、手を入れていなければ手で消す。
- DCB が作っていない同名の `.claude/rules/ai-playbook*.md` が既にあるときは、規則を置かず、`CLAUDE.md` も従来の形（全文を取り込む）のままにして警告する。
- 手を入れていない `CLAUDE.md` は、`--upgrade` で自動的に新しい形へ更新される。
- `.claude/rules/ai-playbook*.md` は正本から生成するものなので、編集は正本（`shared-ai-rules.md`）へ行う。手を入れた規則は、次の `--upgrade` で上書きされず、`.dcb-new` が置かれる。

## v0.23.6

### Summary
- **`scripts/update-check.sh` の追従で、未コミットの変更の確認を、台帳への git の登録より後にした**（ojos/ai-packages-dev#666）。v0.23.5（ojos/ai-packages-dev#658）では、確認したあとで登録していた。そのため、確認してから登録するまでのあいだに別のセッションが同じ作業ツリーへ書き込み、登録を解放すると、汚れた作業ツリーのまま `--upgrade` が走り、追従の差分が他の変更と混ざることがあった。今は先に登録し、そのあとで確かめる。汚れていれば、登録を解放してから止める。
  - 汚れていて、かつ同じ作業ツリーに他のセッションの登録もあるときは、未コミットの変更の案内ではなく、台帳の拒否（ほかのセッション）の案内で止まる。

### 移行
- **`bootstrap.sh --upgrade` で追従する。** 変わる生成物は `scripts/update-check.sh` だけ。
- 手で行う作業は無い。

## v0.23.5

### Summary
- **`.env` に `UPDATE_CHECK=off` を書くと、`scripts/check-no-secrets.sh` が `SECRETS_FAIL` になっていたのを直した**（ojos/ai-packages-dev#657）。雛形の `.env.example` が案内するとおりに書いた `.env` で、キーの整合の検査が「.env にあるキーが .env.example に無い: UPDATE_CHECK」と読み、`verify.sh` と `loop-gate.sh` が止まっていた。雛形ではこの行がコメントなので、整合の検査では `UPDATE_CHECK` を数えない。`UPDATE_CHECK` の優先順位とローダーの読み飛ばしは変えていない。`.env` にだけある、ほかのキーは今のとおり失敗にする。
- **`scripts/update-check.sh` の追従（問いかけの y・手で呼ぶ `upgrade`）が、台帳（`scripts/session-ledger.sh`）を確かめずに作業ツリーのブランチを切り替えていたのを直した**（ojos/ai-packages-dev#658）。追従の初めに、作業ツリーの git の登録を台帳へ出す。同じ作業ツリーに他のセッションの登録があれば、案内を出して何も変えずに止める。
  - 確かめるのは、未コミットの変更の確認のすぐ後で、取得より前。
  - 台帳は作業ツリーへ移ってから呼ぶ（呼び出し元の cwd に左右されない）。
  - 持ち主の PID は update-check 自身なので、強制終了や端末を閉じても、プロセスが消えれば登録は失効する。
  - 登録は、成功・失敗の各経路と EXIT・HUP の後始末で解放する。
  - 台帳が無いとき、読み書きに失敗したときは、警告して通す。
- **`scripts/confirm-merge-hook.sh` が、シングルクォートの中のバックスラッシュと改行まで行継続として取り除き、マージにならないコマンドにも確認を出していたのを直した**（ojos/ai-packages-dev#659）。`gh pr 'mer\<改行>ge' 1` には確認を出さない。
  - クォートを見て継続を取り除くのは、bash の読みを確実に再現できる単純な形だけ。コマンドに `#`・`<<`・`$`・バッククォートのどれかが含まれれば、今までどおり継続を無条件に取り除く。読み違えが起きうる形で、確認を減らさないためである。
  - クォートの外と二重引用符の中の継続は、今までどおり確認を出す。
  - 継続の多い長いコマンド（大きなヒアドキュメントなど）は、merge を含まなければ今までどおりの速さで抜ける。

### 移行
- **`bootstrap.sh --upgrade` で追従する。** 変わる生成物は `scripts/check-no-secrets.sh`・`scripts/update-check.sh`・`scripts/confirm-merge-hook.sh`。
- 手で行う作業は無い。`.env` に `UPDATE_CHECK=off` を書かずに避けていた生成先は、この版から `.env` で止めてよい。

## v0.23.4

### Summary
- **`.env.example` から消えたキーが `.env` に値の空のまま残っていると、`scripts/check-no-secrets.sh` がゲートを止めていたのを直した**（ojos/ai-packages-dev#652）。v0.23.3 で、第二意見のエンジンが codex / antigravity に決まっていて、かつ `--with-gemini` を選んでいない構成の `.env.example` から `GEMINI_API_KEY` の欄を消したため（ojos/ai-packages-dev#646）、以前 gemini を使っていて `.env` に `GEMINI_API_KEY=` が残っている生成先では、v0.23.3 へ追従した直後に「.env にあるキーが .env.example に無い」で `SECRETS_FAIL` になっていた。`.env` にだけある**値の空の**キーは、NOTICE（使っていなければ `.env` から消してよい）に留めて通す。値のあるキーは今のとおり失敗にする。
### 移行
- **`bootstrap.sh --upgrade` で追従する。** 変わる生成物は `scripts/check-no-secrets.sh` だけ。
- v0.23.3 へ追従してゲートが止まっていた生成先は、この版へ追従すれば通る。`.env` の `GEMINI_API_KEY=` の行は、`.env.example` から欄が消えた構成（エンジンが codex / antigravity に決まっていて、`--with-gemini` を選んでいない）なら消してよい（使われない）。

## v0.23.3

### Summary
- **`scripts/update-check.sh` の `UPDATE_CHECK` の優先順位を、推測に頼らない設計へ変えた**（ojos/ai-packages-dev#645）。v0.23.1・v0.23.2 では、`.env` の自動読み込みが `UPDATE_CHECK` を上書きしたうえで、上書き前の値を退避して推測していたため、コマンドで明示した値が、たまたま `.env` を読んだ直後の値と同じだと、退避した値が勝っていた。
  - `scripts/load-project-env.sh` は、`.env` に `UPDATE_CHECK` があっても上書きしない。シェルの `UPDATE_CHECK` は、環境の値か、コマンドで明示した値のまま。
  - `update-check.sh` は、`UPDATE_CHECK` に値があればそれを、無ければ `.env` の値を採る。どんな値の組み合わせでも、環境・明示した値が `.env` より優先される。
  - 退避用の変数 `DCB_ENV_UPDATE_CHECK` / `DCB_ENV_UPDATE_CHECK_LOADED` はやめた。代わりに、ローダーに `.env` の 1 つのキーの値を返す関数 `__load_project_env_value` を足した。
  - 通知の文言を「止めるには UPDATE_CHECK=off（環境の値。無ければ .env の値）」にした。
- **接続時の確認（notify）が、ロックを取ったあとで今日の確認済みの印を読み直すようにした**（ojos/ai-packages-dev#643）。同時の接続で、片方の取得が終わったあとにもう片方が同じ日に取り直し、それが失敗すると、取得済みのキャッシュと印を消していた。手で呼ぶ `update-check.sh upgrade` の取得が失敗しても、既存のキャッシュと印は消さない。
- **y で追従を始める前に、どの作業ツリーのどのブランチが動くかを示すようにした**（ojos/ai-packages-dev#650）。問いかけの文（と手で呼ぶ `upgrade`）に、追従する作業ツリーのパスと、切る作業用のブランチ（または上で追従する今のブランチ）の名前を出す。
- **`.env.example` の `GEMINI_API_KEY` の欄は、第二意見のエンジンが codex / antigravity に決まっていて、かつ `--with-gemini` を選んでいない構成では出さないようにした**（ojos/ai-packages-dev#646）。エンジンが空（既定の gemini で回る）か gemini、または `--with-gemini` を選んだ構成では、今のとおり出す。
- **`scripts/confirm-merge-hook.sh`（マージの直前に確認を挟むフック）が、長いコマンドで長さの 2 乗で遅くなっていたのを直した**（ojos/ai-packages-dev#647）。UTF-8 のロケールでは、20,000 文字のコマンドで 1 回あたり数秒かかり、Bash の呼び出しのたびに待たされていた。走査を長さにほぼ比例する形にし、検知の対象になりうる綴り（`merge`）を含まないコマンドは走査せずに通す。バックスラッシュと改行による行の継続を、bash と同じく取り除いて読むようにした（`gh pr mer\<改行>ge` も検知する）。
- 雛形の `devcontainer.json` の、codex のための AppArmor / seccomp の緩和は残す。第二意見のようにツールを無効にした起動でも、codex は起動のたびに bwrap をサンドボックスの確認として起動することを確かめた（ojos/ai-packages-dev#649）。理由をコメントと README に書いた。
### 移行
- **`bootstrap.sh --upgrade` で追従する。** 変わる生成物は `scripts/update-check.sh`、`scripts/load-project-env.sh`、`scripts/check-no-secrets.sh`、`scripts/confirm-merge-hook.sh`、`.env.example`（構成による）。手を入れていれば `.dcb-new` が置かれる。
- **追従したら、開いているシェルと tmux を開き直す。** v0.23.1・v0.23.2 のローダーは、`.env` の `UPDATE_CHECK` をシェルへ export していた。開いたままのシェル（と、そこから起動した tmux のサーバー）にはその値が残り、新しい `update-check.sh` は、それを環境の値として `.env` より優先する。開き直せば、`.env` の値が効く。

## v0.23.2

### Summary
- **`scripts/update-check.sh` で、そのコマンドで明示した `UPDATE_CHECK` が、親のシェルが退避した値に負けていたのを直した**（ojos/ai-packages-dev#640 / ojos/ai-packages-dev#641）。v0.23.1 の修正（ojos/ai-packages-dev#635）で、対話シェルでは `.env` を読む前の値を `DCB_ENV_UPDATE_CHECK` に退避して優先するようにしたが、退避した値が空でなければ、今の `UPDATE_CHECK` を見ていなかった。そのため、環境で止めたシェルから、そのコマンドだけ `UPDATE_CHECK=on` と明示しても止まったままだった（逆向きも同じ）。今の値が、ローダーが `.env` を読んだ直後の値（`DCB_ENV_UPDATE_CHECK_LOADED`）と違えば、明示したものとして今の値を採る（ローダーが退避し直す条件と同じ考え方）。`bootstrap.sh --upgrade` で追従すれば効く（手で行う移行の作業は無い）。

## v0.23.1

### Summary
- **v0.23.0 で足した `scripts/update-check.sh` の不具合を直した。** `bootstrap.sh --upgrade` で追従すれば効く（手で行う移行の作業は無い）。
  - **ai-playbook の新しい版を通知していなかった**（ojos/ai-packages-dev#631 / ojos/ai-packages-dev#636）。ai-playbook はタグだけを打ち、GitHub の Release を作らないため、`releases/latest` が必ず 404 になっていた（失敗は黙って通すので、「新しい版は無い」と同じに見えていた）。ai-playbook の最新は、タグの一覧から `vX.Y.Z` の最大を取るようにした（ページをたどる。上限 10 ページ）。DCB は今のまま `releases/latest` を読む。
  - **接続時の確認（notify）がキャッシュを更新している最中に開いたシェルでは、新しい版があっても問いかけが出なかった**（ojos/ai-packages-dev#632 / ojos/ai-packages-dev#636）。取得の結果は作業用の場所に集めてから差し替え、更新は専用のロックで排他するようにした（問いかけは更新中でも出る）。取得のどれかが失敗した日は、その日を「確認済み」に数えず、次の接続で取り直す（オフラインのマシンでは、接続のたびに最大 2 秒の問い合わせが残る）。失敗した部品の古いキャッシュは使わない。
  - **問いかけで表示した版と、N で記録する版・y で追従する版がずれることがあった**（ojos/ai-packages-dev#633 / ojos/ai-packages-dev#636）。表示した版を持ち回り、記録と追従にはその版を使う。`update-check.sh upgrade` は、今回取得できた部品だけを対象にする。
  - **`origin/HEAD` の無いリポジトリで、main を既定ブランチと決めつけていた**（ojos/ai-packages-dev#634 / ojos/ai-packages-dev#636）。既定ブランチが master のリポジトリでは、作業用のブランチを切らずに追従の差分を master に残すことがあった。推定をやめ、main / master のどちらの上でも作業用のブランチを切る。
  - **対話シェルでは、環境の `UPDATE_CHECK=off` が `.env` の値に負けていた**（ojos/ai-packages-dev#635 / ojos/ai-packages-dev#637）。`.env` の自動読み込みが先に走るためで、「環境の値が `.env` より優先される」という説明と食い違っていた。`scripts/load-project-env.sh` が `.env` を読む前の値を退避し、`update-check.sh` がそれを優先する。入れ子のシェル（tmux など）でも同じ。`~/.bashrc` / `~/.zshrc` は書き換えない（既に差し込まれた行のまま効く）。新しいシェルから効く。
- キャッシュの `migrations-<部品>` の形式が変わった。v0.23.0 が書いた古い形式は使われず、次の取得で置き換わる（キャッシュはコミットしないので、利用側の作業は無い）。

## v0.23.0

### Summary
- **接続時に DCB と ai-playbook の新しい安定版を知らせ、対話のシェルで yes と答えたときだけ `--upgrade` で追従する `scripts/update-check.sh` を足した**（ojos/ai-packages-dev#625）。**既定で有効**。
  - `on-attach.sh`（接続時）が、ORIGIN の版を GitHub の最新の安定版（`releases/latest`。プレリリースを除く。認証なし・短いタイムアウト）と比べ、新しければ通知を 1 行だけ出す。聞かない。問い合わせは 1 日 1 回で、失敗は黙って通す。
  - `on-attach.sh` が対話のシェルの rc（`~/.bashrc` / `~/.zshrc`）へ問いかけを注入する。端末が付いている対話のシェルでだけ「追従しますか？ [y/N]」と聞く。AI エージェント・CI・スクリプトのシェルでは何も出ない。N と答えた版は、その版のあいだ聞かない（キャッシュは `${XDG_CACHE_HOME:-~/.cache}/dcb-update-check/` の下。コミットしない）。配布先の `CHANGELOG.md` で移行の節を持つ版を 2 つ以上飛び越えるときは `[注意]` で目立たせる（リリースの本文はリリースノートを含まないため）。複数の端末が同時に開いても、聞く・追従するのは 1 つだけ。rc の差し込みの印はプロジェクトごとで、そのプロジェクトの中のときだけ聞く。
  - y のとき、新しい `bootstrap.sh` と `SHA256SUMS` を取得して**照合してから**、ORIGIN を引き継ぐ `--upgrade`（ai-playbook は取得元の種類のまま最新の版を渡す。フォークの url はフォークのまま）を流す。y で上げるのは表示した部品だけで、DCB を上げないときは今の版の `bootstrap.sh` を使う。失敗したとき、何も書かれていなければ作業用のブランチを消して戻り、書かれていれば自動では戻さず作業用のブランチに留まって戻し方を案内する。規範の取得元が `adjacent` / `local` のときは追従せず案内に留める。既定ブランチの上なら作業用のブランチを切る。差分を作業ツリーに残して止め、変わったファイルと次の手順を出す。コミット・push・PR はしない。手で追従するときは `bash scripts/update-check.sh upgrade`。
  - ORIGIN が無い・`version=` がリリースの版（`vX.Y.Z`）でない環境では何もしない。
  - 止め方として、生成のオプション `--no-update-check`（ORIGIN に `input:update-check=off` を記録し、`--upgrade` で引き継ぐ。戻すのは `--upgrade --update-check`）と、環境変数 `UPDATE_CHECK=off`（環境の値が `.env` より優先される。`.env.example` に説明をコメントで足した）を足した。`doctor.sh` は新しい入力キーを認め、値が `off` であることを確かめる。

- **安全性の修正: `.env` の自動読み込みを `~/.bashrc` へ差し込む行が、プロジェクトのパスをシェル用に引用していなかった**（ojos/ai-packages-dev#625 / ojos/ai-packages-dev#628）。パスに `$(...)` や引用符を含むプロジェクトでは、シェルを開くたびに、その部分がコマンドとして実行されていた。差し込む行を `printf %q` で引用するようにした（新しく差し込む版の確認の行も同じ）。悪用には、プロジェクトのディレクトリ名を決められる必要がある。**既に差し込まれた古い行は `--upgrade` では書き直されない**（下の「移行」）。
- **`.env.example` に記入する第二意見のエンジンを、生成時に選べるようにした（`--second-opinion-engine <gemini|antigravity|codex>`）**（ojos/ai-packages-dev#610 / ojos/ai-packages-dev#612）。指定したときだけ ORIGIN に `input:second-opinion-engine` を記録し、`--upgrade` が引き継ぐ。`--with-<エンジン>` で選んでいないエンジンや、記入欄が出ない構成での指定は、生成の前に止める。
- **生成物を「意図して置かない」と ORIGIN に記録できるようにした（`--absent <path>` / `--no-absent <path>`）**（ojos/ai-packages-dev#614 / ojos/ai-packages-dev#616）。記録したファイルは `--upgrade` が作り直さず、`doctor.sh` も欠落を FAIL にしない。ゲート・検証・承認の機構と `devcontainer.json` の 11 件は外せない（README と試験が照合する）。
- **Claude Code の Remote Control を常に有効にするユーザー設定を、オプトインで配れるようにした（`--claude-remote-control` / `--no-claude-remote-control`。`--with-claude` が必要）**（ojos/ai-packages-dev#617 / ojos/ai-packages-dev#620）。`install-ai-tools.sh` が、`~/.claude/settings.json` に `remoteControlAtStartup` が無いときだけ `true` をマージする。失敗は警告に留め、コンテナの作成は止めない。
- **`.env.example` の `SESSION_HOST_LABEL` の説明を直した**（ojos/ai-packages-dev#609 / ojos/ai-packages-dev#611）。宛先名の末尾は、`--resume` に会話の識別子があればその先頭 8 桁、無いときだけ PID の 16 進（動作は変えていない）。
- **`check-shell-portability.sh` の `xargs -r` の規則が、引数の途中の `-r`（`image-replace` など）にも一致していたのを直した**（ojos/ai-packages-dev#613 / ojos/ai-packages-dev#615）。
- **パイプの後ろの `grep -q` の検査が、`| command grep -q` の形も検出するようにした**（ojos/ai-packages-dev#618 / ojos/ai-packages-dev#619）。
### 移行
- **`bootstrap.sh --upgrade` で追従する。** 新しいファイル `scripts/update-check.sh` が置かれ、`scripts/on-attach.sh` が変わる（`on-attach.sh` に手を入れていれば、`.dcb-new` が置かれる）。`.env.example` に `UPDATE_CHECK` の説明（コメント）が足される（既存の `.env` は書き換えない）。
- **既定で有効になる。** 接続時に GitHub の API へ 1 日 1 回、認証なしで問い合わせる。使いたくなければ、`--upgrade --no-update-check`、または `UPDATE_CHECK=off`。
- 追従の `--upgrade` は、作業ツリーに未コミットの変更があるときは実行しない。コミットか退避をしてから。
- **既に差し込まれた `.env` の自動読み込みの行は、`--upgrade` では書き直されない**（印が同じで、二重に足さないため）。パスに `$(...)`・引用符・空白を含むプロジェクトを使っているなら、`~/.bashrc`（と `~/.zshrc`）からその行（印の行とその次の行）を消して、接続し直す（新しい行が引用付きで差し込まれる）。

## v0.22.1

### Summary
- **`check-doc-links.sh` が、作業ツリーで消した（まだステージしていない）追跡済みの Markdown で止まらないようにした**（ojos/ai-packages-dev#599 / ojos/ai-packages-dev#600）。今までは `git ls-files` が消したファイルも列挙するため、`awk` が開けずに「抽出が異常終了」で `DOC_LINKS_FAIL` になり、Markdown を消す作業の途中で `verify.sh` / `loop-gate.sh` が止まっていた。
  - 消したファイル（`git ls-files --deleted` の集合）は、走査の対象からもリンク先の集合からも外す。**消した文書へのリンクは壊れたリンクになり**、診断は「（作業ツリーで消した追跡ファイル。git rm するかリンクを直す）」と出す。
  - sparse-checkout / skip-worktree で作業ツリーに置いていないだけの追跡ファイルは、リンク先として残す（そこへのリンクは通る）。置いていない追跡 Markdown は読めないので走査だけ飛ばし、件数を報告する。壊れたシンボリックリンクは今までどおり失敗させる。
  - 集計の行に「作業ツリーに置いていない N 件」と「実体なし N 件（追跡全体。作業ツリーで消したもの）」を出す。
  - 実在の判定に作業ツリーの有無（`test -e`）は使わない、という方針は変えていない。README の説明を新しい判定（`git ls-files` の集合から `--deleted` を除いたもの）に合わせた。
- README で勧める ai-playbook を v0.12.1 にした。

### 移行
- **`bootstrap.sh --upgrade` で追従する。** ai-playbook を配置している構成では、`--playbook-version v0.12.1` を勧める（v0.11.0 以降なら動く）。
- `check-doc-links.sh` に手を入れていれば、`--upgrade` で `.dcb-new` が置かれる。
- `check-doc-links.sh` の出力を読んでいる仕組みがあれば、集計の行の形が変わったことに注意する。

## v0.22.0

### Summary
- **`.env.example` の第二意見のエンジン（`SECOND_OPINION_ENGINE`）を、選んだエンジンから一意に決まるときは記入済みで出すようにした**（ojos/ai-packages-dev#591 / ojos/ai-packages-dev#592）。記入欄は今までどおり `--with-antigravity` / `--with-codex` を選んだときだけ出る。
  - `--with-gemini` も選んだ構成では `gemini`。明示しておけば、`.env` を持つ作業ツリーでは ai-playbook v0.12.0 の通知（既定へ落ちた知らせ）が出ず、`.env` を写し忘れた作業ツリーでだけ出る。
  - `--with-gemini` を選ばず、`--with-codex` か `--with-antigravity` の片方だけを選んだ構成では、そのエンジン。今までは空で、既定の gemini（CLI もキーも無い）で回り、設定するまで第二意見が使えなかった。
  - `--with-gemini` を選ばず、antigravity と codex の両方を選んだ構成は、どちらを選ぶかが一意に決まらないので、今までどおり空（空なら gemini）。
  - コメントの「既定は gemini」を「空なら gemini」に直した。
- README の、要求する ai-playbook の案内で勧める版を v0.12.0 にした。

### 移行
- **`bootstrap.sh --upgrade` で追従する。** ai-playbook を配置している構成では、`--playbook-version v0.12.0` を勧める（v0.11.0 でも動く。v0.21.0 と同じく、v0.11.0 より前は動かない）。
- **既存の `.env` は書き換えない。** `--upgrade` で変わるのは `.env.example` だけなので、すでに `.env` を持つ利用側には効かない。codex か antigravity の片方だけで生成した構成で、`.env` の `SECOND_OPINION_ENGINE` が空なら、手で設定する。
- `.env.example` に手を入れていれば、`--upgrade` で `.dcb-new` が置かれる。

## v0.21.0

### Summary
- **この版が要求する ai-playbook は v0.11.0 以降**（ai-playbook を配置する構成で）。生成される `scripts/loop-gate.sh` は、ステージ済みの差分があるとき `second-opinion-review.sh --base <起点>` を呼ぶが、`--base` は ai-playbook v0.11.0 の雛形で足したもの（ojos/ai-packages-dev#585）。**古い ai-playbook の `second-opinion-review.sh` と組み合わせると、その経路で第二意見が `error: unknown option: --base` で止まり、loop-gate は「第二意見は判定に到達しませんでした（実行失敗）」を出して記録を残さず、`GATE_FAIL` で終わる**（黙って通ることはない）。ステージ済みの差分が空のとき（`--range` を渡す経路）は古い ai-playbook でも動く。版の検査は機構では行わない。
- **第二意見の既定の対象を、PR 全体にした**（ojos/ai-packages-dev#585）。`loop-gate.sh` は、`origin/HEAD` → `origin/main` → `origin/master` の順で解決した既定ブランチと HEAD の分岐点を起点にし、ステージ済みの差分があれば `--base <起点>`（起点から索引まで）、空なら `--range <起点>..HEAD` を渡す（上流があっても上流からではない）。差分しか見えないエンジンに修正分だけの小さな差分を渡すと、差分に現れない既存のコードについて誤った前提を立てて落ちやすいため。
  - 入力が大きくなる。トークンの消費が増え、大きな PR ではモデルの文脈の上限に近づく。
  - 起点は手元の追跡枝で決まる。`loop-gate.sh` は fetch しないので、追跡枝が古いと起点も古くなる。
  - 既定ブランチの追跡枝を解決できないときだけ、従来に近い決め方に戻る（ステージ済みがあれば reviewer の既定、空なら上流との分岐点 → HEAD。上流が無い、または上流との差分が空なら空ツリー → HEAD）。
  - 記録の scope に、使った範囲（`base:<起点>+staged` / `range:<起点>..HEAD`）を残す。`LOOP_GATE_REVIEW_CMD` で差し替えたコマンドへの範囲の渡し方は変えていない。
- **プロジェクトが所有するファイルを ORIGIN に `owned:` として記録し、`.dcb-new` の取り込み待ちを `pending:` で記録するようにした**（ojos/ai-packages-dev#534 / ojos/ai-packages-dev#566）。対象は `scripts/acceptance.sh` / `scripts/acceptance-remote.sh`。
  - `owned:` のファイルは、日常的に編集しても `doctor.sh` が FAIL にしない（`pending:` が無ければ、現物が `hash:` と違っても `[OK]`）。雛形が変わっていない版への `--upgrade` では `.dcb-new` を置かない。
  - `--upgrade` で `.dcb-new` を置いたファイルには `pending:` が付き、取り込むまで `doctor.sh` が FAIL にする。取り込む前に `.dcb-new` を失っても、`pending:` の記録から作り直す。`--accept` で `pending:` も外れる。現物が `hash:` と一致するのに `pending:` が残っていれば `[WARN]`（`--strict` では非 0）。
  - **`--upgrade` の表示を改名した。`keep (modified, template unchanged)` は無くなり**、`accepted (template unchanged)` / `owned (template unchanged)` / `modified (template unchanged)` のどれかになる（`modified` は doctor が FAIL のまま）。`keep` で始まる行は、取り込み待ち（`.dcb-new`）か、手を入れたため残したものだけになる。
  - 旧い版が置いた `.dcb-new` が残っているのに `pending:` が無いファイルは、置き直さずに `keep (modified, .dcb-new left)` と表示して `pending:` を書き足し、終了コード 2 で知らせる。
- **配布する衛生検査 4 本（`check-control-chars.sh` / `check-table-breaks.sh` / `check-doc-links.sh` / `check-shell-portability.sh`）を、`acceptance.sh` の雛形が呼ぶようにした**（ojos/ai-packages-dev#540 / ojos/ai-packages-dev#579）。言語ごとの検証の後ろで呼ぶ。4 本は「検証を実行した」には数えないので、マニフェストの無い構成が検査だけで合格にはならない。
  - 既存の出力先で `acceptance.sh` が 4 本のファイル名を参照していなければ、`doctor.sh` が `[WARN]`（節「Hygiene checks wiring」）を出し、`--upgrade` が終わりに配線を促す案内を出す（終了コードは変えない）。意図して呼ばない検査は、`acceptance.sh` にファイル名と理由をコメントで書けば WARN も案内も出ない。
- **`--upgrade` に `--baseline-from <dir>` を足した**（ojos/ai-packages-dev#536 / ojos/ai-packages-dev#583）。ORIGIN の無い出力先（または記録に無いファイル）で、旧い版で生成した結果のディレクトリを渡すと、それと一致する現物を「手を入れていない」とみなして新しい版へ更新し（表示は `write: <path> (upgraded, baseline match)`、dry-run は `plan: update (baseline match) <path>`）、手を入れたものだけに `.dcb-new` を置く。`hash:` の記録があれば記録を優先する。
  - `--upgrade` と一緒のときだけ受け付ける。`<dir>` が存在するディレクトリでない・空の文字列・シンボリックリンク・出力先そのもののときは、何も書かずに終了コード 1 で止まる。`--baseline-from` は ORIGIN に記録しない。
  - README に、ORIGIN の無い出力先からの移行の手順（旧い版が分からないときの手作業の手順、baseline は出力先の外に作ること）を書いた。
- **`--with-codex` の緩和（`apparmor=unconfined` / `seccomp=unconfined`）の置き場所を、`compose.yaml` の `security_opt` から `devcontainer.json` の `securityOpt` へ移した**（ojos/ai-packages-dev#543 / ojos/ai-packages-dev#571）。go などの devcontainer feature も `seccomp=unconfined` を足すため、compose に両方が出ると「security_opt items ... are equal」でコンテナが起動しなかった。`devcontainer.json` の `securityOpt` なら devcontainer CLI が重複を除く。
  - **`devcontainer.json` はコメント付き（JSONC）になりうる。** 緩和の理由をコメントで残すため。`doctor.sh` はコメントを除いてから読む（文字列の中は残す。末尾のカンマは許さない）。コメントを除く処理に `perl` を使うので、`doctor.sh` が `perl` に頼るようになった。
- **`.gitignore` の管理セクションを、その場で差し替えるようにした**（ojos/ai-packages-dev#538 / ojos/ai-packages-dev#575）。今までは取り除いてから末尾へ足し直していたため、セクションの後ろにあった利用側の行が前へ移り、否定パターンの効き方が変わりえた。セクションの外の行（空行を含む）は位置も順序も変えない。
  - 開始と終了の対が複数あるときは、1 つ目を差し替え、2 つ目以降を取り除く。
  - 開始行だけ・終了行だけがある壊れた区画は、書き込みの前に検出し、何も書かずに終了コード 1 で止まる（`--dry-run` / `--force` でも）。壊れた行を消すか補う、または `--no-gitignore` を付ける。
- **Claude Code のセッションの宛先名（`CLAUDE_CODE_SESSION_NAME`）の末尾を、会話の識別子の先頭 8 桁にした**（ojos/ai-packages-dev#561 / ojos/ai-packages-dev#577）。起動の引数に `--resume=<id>` / `--resume <id>` があり UUID の形なら使う（小文字にそろえる）。拡張の再読み込みなどでプロセスが起動し直しても、同じ会話なら宛先名が変わらない。
  - 識別子が無いときは従来どおり PID の 16 進。VS Code の拡張が新しい会話の起動の引数に識別子を含めない場合、最初の起動だけ PID の名前になり、最初の再開のときに 1 回だけ名前が変わる。
- **`check-control-chars.sh` が、作業ツリーに加えて索引（ステージ済み）の内容も検査するようにした**（ojos/ai-packages-dev#542 / ojos/ai-packages-dev#584）。禁止バイトをステージしたあとで作業ツリーだけを直しても検出し、`<パス> (staged)` と示す。`assume-unchanged` / `skip-worktree` の印が付いたファイルも索引を読む。
  - 限界: git の clean フィルターが、作業ツリーに無い禁止バイトを索引へ書き込む場合は見逃す。
- **commit identity の検査が偽装を防がないことを、`verify-commit-identity.sh` のコメントと README に明記した**（ojos/ai-packages-dev#541 / ojos/ai-packages-dev#582）。committer / author の email はローカルで自由に設定できるので、GitHub が作ったコミットの形への許可はローカルで作ったコミットにも通る。この検査の目的は identity の適用漏れの検出で、偽装への対策は書き込み権限の管理と、必要なら署名の検証が担う。判定は変えていない。
- README の追記:
  - **コンテナを作り直した直後は、`Developer: Reload Window` を 1 度実行する必要があることを書いた**（ojos/ai-packages-dev#557 / ojos/ai-packages-dev#586）。VS Code の拡張ホストは `postAttachCommand` が `~/.bashrc` に読み込みの行を足す前に起動するため、拡張から起動するプロセス（Claude Code など）に `.env` の値（`GH_TOKEN` など）が届かない。会話を開き直しても直らない。
  - `verify.sh` を回す CI を自前で持つ利用側向けに、`verify.yml` を消さずに自前の CI の中身を移し、`bootstrap.sh --accept .github/workflows/verify.yml` で取り込み済みにする手順を書いた（ojos/ai-packages-dev#539 / ojos/ai-packages-dev#581）。`verify.yml` を消すと doctor が FAIL になり、`--accept` でも消せない（意図した設計）。required check の名前が変わる場合は、ブランチ保護・ruleset の側も直す。
  - ゲートの手動実行に要る PAT の権限（Actions: Read and write）を、実測済みの記載に書き換えた（ojos/ai-packages-dev#556）。Read-only では `gh workflow run` が HTTP 403 で拒否される。

### 移行
- **`bootstrap.sh --upgrade` で追従する。** ai-playbook を配置している構成では、**`--playbook-version v0.11.0` を付けて規範もあわせて上げる**（付けないと、ステージ済みの差分があるときの第二意見が `--base` を知らずに失敗し、`loop-gate.sh` が `GATE_FAIL` になる）。ai-playbook を配置していない構成には付けない（付けると、ai-playbook を新たに配置する）。
- **`doctor.sh` は `bootstrap.sh` と同じ版を使う。** 旧い `doctor.sh` は、この版が ORIGIN に書く `owned:` / `pending:` の行を「認識できない行」として FAIL にする。
- `--upgrade` の出力を読んでいる利用側の仕組みがあれば、表示の改名（`keep (modified, template unchanged)` が無くなった）に合わせる。
- この版へ上げる前に、旧い版で `.dcb-new` を取り込まずに失っていたファイルは、`pending:` の記録が無いので作り直されない。
- **手を入れていない `acceptance.sh` は、`--upgrade` で新しい版になり、衛生検査 4 本が動き始める。既存のコードで赤になりうる。** 手を入れた `acceptance.sh` には `.dcb-new` と `pending:` が付き、取り込むまで doctor が FAIL になる。取り込まずに配線しない場合は、doctor の新しい WARN が `--strict` の結果を変える（4 本を呼ぶか、意図して呼ばない検査をファイル名と理由でコメントに書く）。
- **`--with-codex` で生成した出力先では、`compose.yaml` と `devcontainer.json` の両方の雛形が変わる。** 手を入れていなければ `--upgrade` で移り、手を入れていれば `.dcb-new` が置かれる。取り込むときは、`compose.yaml` の `security_opt` を消し、`devcontainer.json` に `securityOpt` を置く。
- **`devcontainer.json` を `jq` で直接読んでいる利用側の検査は、コメントを除いてから渡す必要がある**（`devcontainer.json` が JSONC になりうるため）。
- `.gitignore` の管理セクションの開始行・終了行の片方だけが残っている出力先では、`bootstrap.sh` が止まる。壊れた行を消すか補ってから実行し直す。
- ORIGIN の無い出力先では、旧い版で生成した結果を出力先の外に作り、`--upgrade --baseline-from <dir>` で上げられる（手順は README）。

## v0.20.0

### Summary
- **この版が要求する ai-playbook は v0.10.0 以降**（定期実行をなくし（ojos/ai-packages-dev#545）、`runs-on` を変数にした（ojos/ai-packages-dev#546）版）。 配置する規範の雛形（`review-gate.yml` / `second-opinion-gate.yml`）から `on.schedule` がなくなる。
- **`--with-copilot-review` と規範の配置で生成されるゲートのワークフローが、20 分ごとの定期実行を持たなくなった**（ojos/ai-packages-dev#545）。定期実行は PR が 1 本も無いあいだも走り続けるため、private リポジトリでは Actions の課金枠を減らし続ける。利用側の実測では、7 日間に 438 回走り、Actions の実行全体の約 72% を占めた。
  - 代わりに、`scripts/second-opinion-record.sh post` が投稿の直後に確認側を既定ブランチで手動実行（`workflow_dispatch`）し、`/land` がマージの直前に再判定する。
  - 手動実行には、トークンの Actions の書き込み権限（fine-grained PAT なら Actions: Read and write）が要る。README の PAT の権限の表に足した。GitHub の公式ドキュメントに基づく記載で、実測ではない。
  - 生成した出力に `schedule` が無いことを、`tests/test-review-gate.sh` が確かめる。
- **生成されるワークフロー 5 本（`identity-guard.yml` / `verify.yml` と、規範の雛形の 3 本）の実行先を、リポジトリ変数 `ACTIONS_RUNS_ON` で切り替えられるようにした**（ojos/ai-packages-dev#546）。`runs-on` は `${{ vars.ACTIONS_RUNS_ON || 'ubuntu-latest' }}`。未設定・空なら従来どおり `ubuntu-latest`。private リポジトリで自前のランナーへ向けると、GitHub のランナーの課金枠を使わない。
  - README に変数名・既定値・自前のランナーへ向けるときの注意（外部からの PR を受けるリポジトリでは使わない）と、自前のランナーに要る道具の一覧（git / gh / GNU coreutils など）を書いた。
  - この版が要求する ai-playbook は、上の雛形の変更（ojos/ai-packages-dev#546）を含む版。**`--playbook-version` にこの変更を含まない古い ai-playbook を指定すると、`bootstrap.sh` が書く 2 本（`identity-guard.yml` / `verify.yml`）だけが変数の形になり、規範の雛形の 3 本は `ubuntu-latest` のまま残る。5 本すべてを変数の形にするには、この変更を含む ai-playbook と組み合わせる**（版の検査は機構では行わない）。

### 移行
- **`bootstrap.sh --upgrade` で追従する。** ai-playbook を配置している構成では、`--playbook-version v0.10.0` を付けて規範もあわせて上げる（付けないと、規範の雛形の 3 本は古いまま残る）。ai-playbook を配置していない構成には付けない（付けると、ai-playbook を新たに配置する）。雛形から写したワークフローに手を入れていなければ置き換わる（ORIGIN の hash が一致するもの）。置き換わるのは、`on.schedule` の削除（ojos/ai-packages-dev#545）と `runs-on` の変数化（ojos/ai-packages-dev#546）の 2 点。置き換わると、利用側の定期実行が止まる。`runs-on` は変数 `ACTIONS_RUNS_ON` を設定しない限り `ubuntu-latest` のままで、挙動は変わらない。
- 手を入れたワークフローは置き換わらない。`on:` の `schedule:` と `cron:` を手で外し、`runs-on:` を手で同じ形にする。
- `post` を打つトークンに Actions の書き込み権限が無いと、`post` は記録を投稿したあとで非 0 になる。手で起こすコマンドが出力される。

## v0.19.2

### Summary
- **この版が要求する ai-playbook は変わらない**（`--with-claude` では v0.9.0 以降、使わない場合は v0.5.0 以降）。land スキルの修正（ojos/ai-packages-dev#523）が入っている v0.9.2 を勧める。
- **タブや改行を含むパスを、台帳の欄に書かないようにした**（ojos/ai-packages-dev#528。`session-coord-hook.sh` と `session-ledger.sh`）。 台帳はタブ区切り、登録の対象と解放の一覧は改行区切りなので、含むパスは 1 つの値として持てない。v0.19.1 では、`git -C` 先などが改行を含むと 1 つのパスが 2 行に割れ、存在しない 2 つのディレクトリで登録・解放して、本物の作業ツリーの登録が解放されず、失効するまで他のセッションを止め続ける状態になりえた。また、作るブランチの控え（印）のタブの検査は、印をタブ区切りで読んだあとに行っていたため働いていなかった。利用者への影響は、パスにタブや改行を含む作業ツリーという異常な場合に限る。
  - 守るのは「危険なパスを台帳の欄に書かない」ことだけで、作業ディレクトリが危険だからといって何もしない形にはしない。パスを持たない種類（merge・gate・issue）は、作業ディレクトリが危険でも従来どおり確かめて登録し、拒否も効く（台帳が作業ツリーの欄に `-` を書く）。解放の経路（`PostToolUse` / `PostToolUseFailure` / `SessionEnd`）も続ける。登録した台帳の控え（フックの一時ファイルの印）は、危険な作業ディレクトリも符号化（`%` → `%25`、タブ → `%09`、改行 → `%0A`）して持ち、コマンドの `cd` で `PostToolUse` の作業ディレクトリが変わっても、登録した台帳から解放する（解放の行は重複しない）。
  - 危険かどうかは、台帳の欄へ書く値で判定する。フックは、`git` の操作の作業ツリー（`cd` 先・`git -C` 先（重ねた `-C` を含む）。絶対パスの `-C` は基準のディレクトリに依存せず、その先だけで判定する）と、作るブランチの控えを、解決した結果で判定し、危険なものは登録せず、警告を 1 行出して通す。安全なリポジトリの中の危険なサブディレクトリにいるだけでは止めない。文書の確認は `file_path` 自体で判定する。作るブランチの控えが危険なときは、印は番号だけになり、失敗時は従来どおり解放する。
  - `session-ledger.sh` は、対象の欄へ来るパス（`git` の作業ツリー・文書のパス・`release '*' <対象>` の対象）が、正規化の前後（シンボリックリンクをたどった実体のパスを含む）で危険なとき、書き込まずに `LEDGER_SKIP`（警告を出し、終了コード 0。2 行目に `reason: unsafe-path`）で通す。フックは、この理由の印があるとき、台帳が読めなかった場合の汎用の警告を重ねない。
  - パスは、末尾の改行を削らない取り出し方（末尾に目印を付ける）で値のまま判定する。フックの `cwd`・`file_path`、解決した作業ツリーのルート（シンボリックリンクの先を含む）、台帳の作業ツリーと正規化した実体のパスが対象。jq が無い経路も、JSON の `\t` / `\n` を空白にせず、値のまま判定する。
  - 解決に失敗した危険な `-C` 先（存在しない先など）は、安全な基準のディレクトリへ置き換えず、危険として扱う（登録せず、警告して通す）。台帳は、相対パスの正規化で作業ディレクトリの末尾の改行を削らない（末尾が改行の作業ディレクトリから作業ツリーを相対パスで登録しても、別の安全なパスにならず、飛ばされる）。
  - **挙動の変更（改善）:** コマンド節を語に分ける読み取りが、語に含まれる改行を保つようになった。改行を含むクォートの語より後ろの語も判定の対象になる（例: `MSG="a<改行>b" gh pr merge 5` を、旧版は 1 行目で切れて検出しなかったが、merge として検出する）。語の分割は、節ごとの部分シェルを起こさない形にした。
  - 危険なパスを持つ作業ツリーでの `git` の操作や、危険なパスの文書では協調が働かない（台帳の欄にパスを符号化して書くことはしない。符号化するのは、フックの一時ファイルの印だけ）。タブ・末尾がタブ・改行・末尾が改行のパスのそれぞれで、誤った登録が残らず、印に壊れたパスが書かれないことを、テストで確かめる。

### 移行
- **`bootstrap.sh --upgrade` で追従する。** ai-playbook を配置している構成で、あわせて v0.9.2 へ上げるときは `--playbook-version v0.9.2` を付ける。ai-playbook を配置していない構成には付けない（付けると、ai-playbook を新たに配置する）。生成物では `scripts/session-ledger.sh`（装備フラグに関わらず生成）と `scripts/session-coord-hook.sh`（`--with-claude` の構成だけ）が変わる。手を入れていなければ更新され、手を入れていれば従来どおり `.dcb-new` が置かれる。
- 台帳の書式は変わらない。v0.19.1 の台帳をそのまま読む。コンテナを作り直す必要は無い（フックは次の呼び出しから新しい版が動く）。

## v0.19.1

### Summary
- **この版が要求する ai-playbook は変わらない**（`--with-claude` では v0.9.0 以降、使わない場合は v0.5.0 以降）。land スキルの CI の待ちの修正（ojos/ai-packages-dev#513）が ai-playbook v0.9.1 に入っているので、`--playbook-version v0.9.1` を勧める。
- **Claude Code の起動役の設置を、`devcontainer.json` の `onCreateCommand` 自身に持たせた**（ojos/ai-packages-dev#511）。`--with-claude` の構成で、`onCreateCommand` は `scripts/on-attach.sh` を呼ばずに、起動役 `~/.local/bin/claude-session-launcher` を直接書き出す（一時ファイルへ書いて置き換える。失敗しても作成は止めず警告する）。配線（`claudeCode.claudeProcessWrapper`）と設置が同じファイルにあるので、`--upgrade` で `devcontainer.json` が更新されれば両方とも入り、`.dcb-new` になれば両方とも入らない。片方だけが新しい状態は起きない。
  - v0.19.0 の移行の注意（作り直す前に `devcontainer.json` と `scripts/on-attach.sh` の両方が新しい版であることを確かめる）のうち、`devcontainer.json` が新しく `on-attach.sh` が古いままのずれは、この版では起きない。`on-attach.sh` が古いままでも、起動役は置かれる。
  - 逆向きのずれ（`devcontainer.json` が v0.19.0 のまま残り、`on-attach.sh` だけが新しい）では、`onCreateCommand` が今も `on-attach.sh --install-launcher` を呼ぶので、この経路は `on-attach.sh` の `--install-launcher` に頼る。`devcontainer.json` が `.dcb-new` のまま残っていないかを、作り直す前に確かめる。
  - 起動役の中身の正本は `bootstrap.sh` の 1 か所で、`onCreateCommand` と `scripts/on-attach.sh` の両方へそこから書き出す。`scripts/on-attach.sh` の `--install-launcher` は、v0.19.0 の `devcontainer.json` の `onCreateCommand` が呼ぶため残す。
- **`session-coord-hook.sh` が、ブランチを作ってから失敗した呼び出しで issue の登録を解放しないようにした**（ojos/ai-packages-dev#514。利用側のプロジェクトからの報告による）。`git switch -c 26-x && npm test` のように、ブランチを作ったあとの段で失敗（`PostToolUseFailure`）すると、作業は issue で続いているのに登録が消え、別のセッションへの重複着手の警告が出なくなっていた。ブランチ名の読み方を `ISSUE_BRANCH_RE` の 1 か所にまとめ、呼び出しの前（PreToolUse）に、作るブランチの正確な名前・そのブランチを作るリポジトリ（`cd` や `git -C` を解決したもの）・呼び出しの前から既にあったかを印へ控え、失敗したとき、そのブランチがそのリポジトリに「いま」あり、かつ呼び出しの前には無かった場合だけ登録を残す。既にあったブランチへの `checkout -b` の失敗や、同じ番号の別のブランチがあるだけの場合、ブランチが作られずに失敗した場合は従来どおり解放する。番号だけの古い書式の印も読み、従来どおり解放する。ブランチがあるかは、`show-ref` に加えて HEAD がそのブランチを指しているか（`symbolic-ref`）も見る（まだコミットの無いリポジトリに対応するため。呼び出しの前と後で同じ判定を使う）。`git -C` を重ねたときは、前から順に積み上げて解決する。パスにタブを含むリポジトリでは、作ったブランチを正しく記録できないため、従来どおり解放する（異常なパスは、この修正の前と同じ動きに倒す）。成功した呼び出しの扱いは変えない。README の「issue はブランチ作成の時点で登録し、`SessionEnd` まで持つ」という説明に、コードを合わせる修正。
- **生成物が変わる**（`--with-claude` の構成だけ）。`devcontainer.json` の `onCreateCommand`、`scripts/on-attach.sh`（コメントと、起動役の中身の 1 行のコメントだけ）、`scripts/session-coord-hook.sh`（ojos/ai-packages-dev#514）が変わる。

### 移行
- **`bootstrap.sh --upgrade --playbook-version v0.9.1` で追従する**（`--with-claude` の構成）。手を入れていないファイルは更新され、手を入れたファイル（`devcontainer.json` など）には従来どおり `.dcb-new` が置かれる。
- **`devcontainer.json` に `.dcb-new` が置かれたら、取り込んでから作り直す。** この版から、起動役の設置は `devcontainer.json` の `onCreateCommand` 自身が行うので、`devcontainer.json` が新しくなれば、`on-attach.sh` の版によらず起動役が置かれる。`devcontainer.json` が v0.19.0 のまま残る場合は、v0.19.0 の移行の注意（`on-attach.sh` も新しい版にしてから作り直す）が引き続き当てはまる。
- 作り直したら、`test -x ~/.local/bin/claude-session-launcher` で起動役が置かれたことを確かめる。

## v0.19.0

### Summary
- **同じプロジェクトで動くほかの Claude Code セッションへ、指示を簡単に送れるようにした**（ojos/ai-packages-dev#502）。どれも `--with-claude` のときだけ生成する。
  - `scripts/session-peers.sh`: 同じコンテナで生きている、同じリポジトリのセッションを、番号・宛先名・作業ツリー・台帳の issue・状態で一覧する。宛先を番号・`#issue`・宛先名・作業ツリー名で解決し、送り元の署名の行を出す。Claude Code が書く `~/.claude/sessions/*.json`（公開された仕様ではない）と、セッションの台帳を突き合わせる。読めないときは警告して `ListAgents` を案内する。
  - `scripts/claude-session-wrapper.sh`: 場所ラベル `SESSION_HOST_LABEL`（`.env`、無ければ環境変数）があれば、宛先名を `<SESSION_HOST_LABEL>-<作業ツリー名>-<PID の16進>` にする。ラベルは Claude Code を起動するたびに読む。ラベルが無い・失敗した・`CLAUDE_CODE_SESSION_NAME` を自分で設定しているときは、何も変えずに起動する。
  - 起動役 `~/.local/bin/claude-session-launcher`: `devcontainer.json` の `claudeCode.claudeProcessWrapper` が指す、作業ツリーの外の小さな sh。起動したときの作業ツリーにラッパーがあれば呼び、無ければそのまま起動する（ラッパーの無いブランチへ切り替えても、Claude Code が起動しなくなることは無い）。`onCreateCommand`（`on-attach.sh --install-launcher`）と、接続のたびの `on-attach.sh` が設置する。
  - `/peers` スキル（`.claude/skills/peers/SKILL.md`。雛形は ai-playbook v0.9.0）: 一覧・宛先を解決しての送信・一斉送信。一斉送信は、送る前に宛先の一覧を利用者に確認する。
  - `.env.example` に `SESSION_HOST_LABEL=`（値なし）を足した。
- **この版が `--with-claude` で要求する ai-playbook は v0.9.0 以降**（雛形 `claude-skill-peers.md` が必要）。それより前の規範を指定すると、`template not found` で書き込む前に停止する。`--with-claude` を使わない場合は、従来どおり v0.5.0 以降。
- **規範の雛形が欠けているときに、何も書き込まずに止まるようにした**（ojos/ai-packages-dev#507）。これまでは、古い規範（必要な雛形が無い版）を指定すると、一部のファイルを書き込んでから `template not found` で止まり、生成物と `.devcontainer/ORIGIN` が食い違った状態が残っていた。いまは、書き込みの前に構成に必要な雛形をすべて確かめ、欠けたものをまとめて報告して止まる（`--dry-run` も計画を出す前に止まる）。
- **生成物が変わる**（`--with-claude` の構成だけ）。上の 2 本のスクリプトとスキルが増え、`devcontainer.json`（`onCreateCommand` と `customizations.vscode.settings` の `claudeCode.claudeProcessWrapper`）、`scripts/on-attach.sh`、`.env.example` が変わる。

### 移行
- **`--upgrade` は、`--playbook-version v0.9.0` と合わせて当てる**（`--with-claude` の構成）。`--upgrade` は、明示しなければ ORIGIN に記録した規範の版を使い回すので、付けないと v0.8.2 以前の雛形のままになり、`template not found` で止まる（何も書き込まずに止まるので、付け直して当て直せばよい）。手を入れていないファイルは更新され、手を入れたファイル（`devcontainer.json` など）には従来どおり `.dcb-new` が置かれる。
- **作り直す前に、`devcontainer.json` と `scripts/on-attach.sh` の両方が新しい版になっていることを確かめる。** どちらかに手を入れていると、`--upgrade` はそのファイルを更新せず、隣に `<path>.dcb-new` を置く。
  - `devcontainer.json` が古いままだと、配線（`onCreateCommand` と `claudeCode.claudeProcessWrapper`）が入らない。宛先名は従来どおりで、ほかは何も変わらない。
  - **`devcontainer.json` だけが新しく、`on-attach.sh` が古いままだと、Claude Code が起動しなくなる。** 古い `on-attach.sh` は `--install-launcher` を知らないので起動役が置かれず、`claudeCode.claudeProcessWrapper` が存在しないパスを指すため。
  - `.dcb-new` があれば、手を入れた箇所を残して取り込んでから作り直す（取り込んだら `bootstrap.sh --accept <path>` で記録できる）。
- **配線は、コンテナを作り直すと効く。** `claudeCode.claudeProcessWrapper` と `onCreateCommand` は、作り直したときに読まれる。作り直したら、`test -x ~/.local/bin/claude-session-launcher` で起動役が置かれたことを確かめる。
- **場所ラベルのためだけに作り直す必要は無い。** ラッパーは起動のたびに `.env` の `SESSION_HOST_LABEL`（例: `mac-main`）を読むので、設定したあとに開いたセッションから宛先名に場所が入る。設定しなければ、宛先名は従来どおり。
- **万一 Claude Code が起動しなくなったら**、VS Code のリモートの設定で `claudeCode.claudeProcessWrapper` を空にすれば元に戻る。

## v0.18.0

### Summary
- **この版が要求する ai-playbook は v0.5.0 以降のまま**（新しい雛形を必須にしない）。ai-playbook v0.8.2 は README だけの変更なので、`--playbook-version v0.8.2` にしても生成物は変わらない（変わるのは版の記録だけ。`.ai-playbook/VERSION` と、`.devcontainer/ORIGIN` の `input:playbook-ref`）。
- **`bootstrap.sh` / `doctor.sh` / 生成物は v0.17.0 から変わらない**（版の記録 `DCB_VERSION` を除く）。`--upgrade` で追従すると、書き換わるのは `.devcontainer/ORIGIN` の版の記録だけで、手を入れたファイルにだけ従来どおり `.dcb-new` が置かれる。
- **README に 3 パッケージ（ai-playbook / DCB / devcontainer-host）の関係を明示した**（ojos/ai-packages-dev#494）。それぞれ単体で使え、DCB を中心に組み合わせると効果が最大になる。DCB はほかの 2 つが着地する devcontainer を作り、ai-playbook の規範はその中に置かれ、devhost はそのコンテナを外部の機械で動かし続ける。devhost の節は、移り先の案内に加えて「devcontainer を外部の機械で常駐させる道具（DCB の生成物と組み合わせると前提が揃う）」として紹介する形にした。
- **テストだけの変更**（ojos/ai-packages-dev#480）: テストの起動関数でベースイメージを固定し、`bootstrap.sh` を起動するたびのレジストリへの問い合わせをなくした。配布物は変わらない。
- **`SHA256SUMS` に `PACKAGE_ARCHIVE.tar.gz` を加えた**（ojos/ai-packages-dev#491）。attestation の対象は `SHA256SUMS` 1 つなので、アーカイブが含まれていないと attestation からアーカイブまで辿れなかった。README の入手手順も、`SHA256SUMS` の行を抜き出して検証する形と、照合に失敗したら展開しない形（`&&` でつなぐ）に合わせた。
- **devhost の同梱をやめた**（ojos/ai-packages-dev#486）。`PACKAGE_ARCHIVE.tar.gz` の `devhost/` と、README の「devhost」の節が指していた入手方法は、この版から無い。devhost（SSH で届く外部の機械で devcontainer を保つ道具。コマンド `dev`）は、独自の版を持つ公開リポジトリ `ojos/devcontainer-host` のリリースで配る。入手の手順は、そのリポジトリの README の「devhost を入手する」にある。`bootstrap.sh` / `doctor.sh` / 生成物は変わらない。

### 移行
- **DCB v0.14.0〜v0.17.0 に同梱されていた `dev` を使っている場合**: その `dev self-update` は取得先が DCB のリリースなので、この版以降の最新リリースでは `devhost/` が無く、何も置き換えずに止まる（終了コード 1）。**手で 1 度だけ入れ直す。** `ojos/devcontainer-host` のリリースから `RELEASE-MANIFEST.json` と `PACKAGE_ARCHIVE.tar.gz` を取得し、マニフェストの `checksums` と照合してから、`dev.sh` を `~/.local/bin/dev` へ置き直す。以降の `dev self-update` は `ojos/devcontainer-host` のリリースから更新できる。DCB の v0.17.0 以前のリリースに残る `devhost/` を取り出して使い続けることもできるが、更新は止まる。
- DCB の生成物は変わらないので、`--upgrade` での追従は従来どおり（手を入れたファイルにだけ `.dcb-new` が置かれる）。

## v0.17.0

### Summary
- **この版が要求する ai-playbook は v0.5.0 以降のまま**（新しい雛形を必須にしない）。第二意見の雛形の小さな修正（ojos/ai-packages-dev#462 / ojos/ai-packages-dev#471）が ai-playbook v0.8.1 に入っているので、`--playbook-version v0.8.1` を勧める。
- **生成する `compose.yaml` の `app` サービスに `init: true` を足した**（ojos/ai-packages-dev#469）。PID 1 の `sleep infinity` は、親を失ったプロセスを回収しない。コンテナの中で孤児になったプロセス（シェル・git・テストの子など）がゾンビとして溜まり続け、数日でプロセス数の上限に達して、`docker exec`（エディタの接続）もコンテナの中のセッションも止まっていた（実測: `pids.current` 18034 / `pids.max` 18039、別の環境ではゾンビ 28517 個）。`init: true` で PID 1 を Docker の組み込みの init にし、孤児を回収させる。**効かせるには、コンテナの作り直し（Rebuild）が要る。**
- **`bootstrap.sh --accept <path>...` を足した**（ojos/ai-packages-dev#461）。パッケージの指示どおりに手を入れ、取り込みを済ませたファイルを、`.devcontainer/ORIGIN` に `accepted:<path>=<ハッシュ>` として記録する。`doctor.sh` は、現物が取り込み済みの記録と一致すれば OK とし（`accepted as merged`）、記録とも雛形とも違えば従来どおり FAIL にする。これまでは手を入れたファイルで `doctor.sh` が常に FAIL し、利用側では解消できなかった（ORIGIN を手で書き換えるしかなかった）。受け付けるのは、ORIGIN に記録があり、現物があり、`.dcb-new` が残っていないパスだけ。`--output-dir` と `--dry-run` だけと併用できる。
- **`--upgrade` は、雛形が変わっていない版で、取り込み済みにしたファイルに `.dcb-new` を置かなくなった**（ojos/ai-packages-dev#461）。「新しい版 = 記録」かつ「現物 = `accepted:`」のときだけ温存して `keep (modified, template unchanged)` と報告する。取り込み済みにしていないファイルには従来どおり置く（取り込む前に失った `.dcb-new` も、同じ版の `--upgrade` で作り直される）。`accepted:` は、温存したファイルの分だけを引き継ぐ。
- **生成物の末尾を改行で終えるようにした**（ojos/ai-packages-dev#462）。`.env.example`・`scripts/*.sh`・`compose.yaml`・workflows など 25 本の末尾に改行が無く、手で整えた版や `.dcb-new` との diff に `\ No newline at end of file` が出ていた。**生成物の中身が変わる**ので、`--upgrade` で手を入れていないファイルは更新され、手を入れたファイルには `.dcb-new` が置かれる。
- **`--upgrade` のたびに `.gitignore` の管理区画の手前へ空行が 1 行ずつ累積する不具合を直した**（ojos/ai-packages-dev#460）。累積していた空行も、次の `--upgrade` で 1 行に戻る。
- **配布スクリプトの「パイプの後ろの `grep -q`」を取り除いた**（ojos/ai-packages-dev#471）。`grep -q` は一致した時点で読むのをやめるので、生産側が SIGPIPE を受けて `printf: write error: Broken pipe` を出すか、`pipefail` の下で一致を不一致と取り違える。`bootstrap.sh` とそのヒアドキュメントの中の配布スクリプトの 13 か所を、`-q` を外して `>/dev/null` を付ける形にした。
- **devhost に `dev rebuild` / `dev doctor` / `dev help` を足した**（ojos/ai-packages-dev#472 / ojos/ai-packages-dev#475）。`PACKAGE_ARCHIVE.tar.gz` の `devhost/` に入る。
  - `dev rebuild <名前> [--pull]` は、ユニット `dev-up@<名前>` が動いていれば止めてから作り直し、起こし直す（作り直しの途中でユニットの `up` と重ならない）。中断（ssh の切断を含む）でも、止めたユニットは起こし直す。`--pull` は作り直す前に `git pull --ff-only` する。
  - `dev doctor <名前>` は、コンテナの状態、exec の疎通、プロセス数（上位の cgroup まで遡る）、ゾンビの数、`oom_kill`、ユニットの状態を 1 回で出す。「コンテナは動いているのに入れない」状態を、ホストに入らずに見分ける。
  - `dev attach` は、入れなかったときに `dev doctor` と `dev rebuild` を案内する。
  - `dev help <サブコマンド>` の説明は、devhost の README の「コマンドの説明」と照合している。

### 移行
- **`compose.yaml` の `init: true` は、`--upgrade` で取り込んだあと、コンテナを作り直すまで効かない。** 手を入れた `compose.yaml` には `.dcb-new` が置かれるので、`command: sleep infinity` の次の行へ `init: true` を写してください。作り直す前に溜まったゾンビは、作り直しで消える。
- **生成物の末尾の改行（ojos/ai-packages-dev#462）で、手を入れたファイルには `.dcb-new` が置かれる。** 中身の違いが末尾の改行だけなら、`.dcb-new` で置き換えてから手を入れ直すか、末尾に改行を足して `.dcb-new` を消してください。取り込みが済んだら `bash bootstrap.sh --accept <path>` で取り込み済みにすると、次から `doctor.sh` が FAIL を出さなくなる。
- **規範（ai-playbook）も v0.8.1 へ上げるには、`--upgrade --playbook-version v0.8.1` と指定する。** `--upgrade` は、明示しなければ ORIGIN に記録した規範の版（`input:playbook-ref`）を使い回す。指定しなくても、DCB 自身の生成物（`compose.yaml`・`scripts/*.sh` など）は新しい版になるが、規範から写す `scripts/second-opinion-review.sh` などは前の版のまま。
- `--accept` を使わない場合のふるまい（手を入れたファイルに `.dcb-new` を置く・`doctor.sh` が FAIL を出す）は従来と同じ。

## v0.16.0

### Summary
- **この版が要求する ai-playbook は v0.5.0 以降のまま**（新しい雛形を必須にしない）。`CLAUDE.md` に規範を取り込む節（ojos/ai-packages-dev#441）は ai-playbook v0.8.0 の `templates/claude-entry-imports.md` を使い、それより前の版では節なしで置いて `note:` で案内する。第二意見の記録の経路の修正（ojos/ai-packages-dev#436 / ojos/ai-packages-dev#437 / ojos/ai-packages-dev#440）も ai-playbook v0.8.0 に入っているので、`--playbook-version v0.8.0` を勧める。
- **生成する `CLAUDE.md` に、規範 2 つを全文取り込む節を足した**（ojos/ai-packages-dev#441）。末尾に `@.ai-playbook/shared-ai-rules.md` と `@.github/project-ai-rules.md` の 2 行を置き、Claude Code が規範を毎セッションの文脈へ載せる（生成物で約 53KB）。従来はパスを挙げるだけで、エージェントが読みにいかない限り規範は文脈に載らなかった（ツールを使わせない問いに、規範の中身を「不明」と答えた）。`AGENTS.md` / `copilot-instructions.md` は雛形のまま。節の中身は ai-playbook の `templates/claude-entry-imports.md` が持ち、DCB は `entry.md` の後ろへつなげるだけ。この雛形が無い ai-playbook（v0.8.0 より前）では、従来どおり節なしで置き、`note:` で案内する（要求する ai-playbook の版は上げない）。
- **`scripts/verify-commit-identity.sh` が、範囲が空で何も検査せずに通ったときに、そのことと `--full` の案内を出すようにした**（ojos/ai-packages-dev#442）。push した後に loop-gate を回すと範囲（`origin/main..HEAD`）が空になり、`IDENTITY_PASS` だけでは検査が済んだと取り違えやすかった。`IDENTITY_PASS` の行と終了コードは変えない（読む側の loop-gate・CI はそのまま）。
- **README の「利用側の設定手順（許可 author email）」に、新しいリポジトリでの順番を足した**（ojos/ai-packages-dev#443）。リポジトリ変数 `ALLOWED_AUTHOR_EMAILS` はリポジトリを作ってからでないと設定できないため、生成物をそのまま最初に push すると identity-guard が必ず失敗する。リポジトリを作る → 変数を設定する → push する、の順を案内し、先に push した場合の再実行の手順も書いた。
- **`scripts/check-doc-links.sh` が、コードフェンスの閉じを CommonMark どおりに判定するようにした**（ojos/ai-packages-dev#439）。閉じるのは、開きと同じ文字で開き以上の長さを持ち、後ろに空白しか無い行だけ。従来は文字の種類だけで見ていたため、4 連のバッククォートのフェンスの中に書いた ``` や ```sh の例でフェンスが早く閉じ、続くコードの中のリンクを検査し、最後のフェンスを「閉じていない」と報告していた。
- **セッション協調のフック `scripts/session-coord-hook.sh` が、index を変える `git add` / `commit` / `rm` / `mv` も作業ツリーの git 操作として登録し、同じ作業ツリーで他のセッションと重なれば拒否するようにした**（ojos/ai-packages-dev#438）。従来は対象外で、同じ作業ツリーで 2 つのセッションが同時に add・commit しても検出されなかった（一方が stage したものを他方の commit が取り込む、`.git/index.lock` で片方が落ちる）。登録はコマンドの実行のあいだだけなので、止まる時間は短い。
- **`--upgrade` で装備を外せるようにした**（ojos/ai-packages-dev#444）。`--with-<名前>` ごとに対になる `--without-<名前>`（aws / gcp / claude / gemini / antigravity / codex / copilot / copilot-review）を足した。`--upgrade --without-<名前>` は記録した集合から外し、ORIGIN の `flags=` からも消す。外したフラグでだけ生成していたファイルは、ORIGIN に記録したハッシュと一致する（手を入れていない）ものだけを削除し、手を入れたものは残して報告する。`--dry-run` では `plan: remove` と出して何も消さない。削除の対象の親ディレクトリが出力先の外を指すシンボリックリンクなら、ほかの生成物も ORIGIN も書かずに終了コード 1 で止める（書き込み前の事前検査に削除の対象も含める。ojos/ai-packages-dev#453。`--dry-run` でも同じ）。この削除は外す操作に限った例外で、ほかの理由で生成されなくなったファイルは従来どおり報告だけにする。同じ名前の `--with-` と `--without-` を同時に渡すと、何も書かずにエラーで止まる。`--upgrade` 以外では「付けない」と同じ扱いで、既存のファイルには触れない。従来は「足せるが外せない」ため、外すには生成し直すしかなかった。リモート最終ゲートを外すときの生成物以外の作業（project-ai-rules の記述・required check・Copilot の自動レビューの設定）は README に案内がある。
- **共有台帳 `scripts/session-ledger.sh` の開始時刻のキーを、ホストの時刻の付け直しやタイムゾーンで変わらない値にした**（ojos/ai-packages-dev#433）。従来は `ps -o lstart=` の cksum で、Docker Desktop の VM のようにスリープや復帰で時刻が付け直される環境では、同じプロセスでもキーが変わった。そのため、動いているセッションの登録が他のセッションの check から失効とみなされ、マージ・git 操作・重いゲートの同時実行を止める保護が黙って切れていた。Linux では `/proc/<PID>/stat` の 22 列目（起動からの経過のクロック数）を使い、`/proc` が無い環境（macOS）では `TZ=UTC`・`LC_ALL=C` で読んだ `lstart` の cksum に落とす。
- **台帳の `refresh` が、マージ・git 操作・重いゲートの登録を生かし続けないようにした**（ojos/ai-packages-dev#433）。これらは実行のあいだだけ持つ登録なので、`refresh` で claim し直さず、失効もセッションの最後の更新ではなく、その登録の時刻から数える。フックの版の切り替えや確認（`ask`）の拒否で解放し損ねた登録が、セッションが続く限り他のセッションを止め続けることがなくなる（既定の 8 時間で失効する）。issue と文書の登録は従来どおり `refresh` で延びる。台帳の書式（列）は変えていない。
- **生成する workflow の `actions/checkout@v4` を `@v7` へ上げた**（ojos/ai-packages-dev#432）。対象は `.github/workflows/identity-guard.yml` と `.github/workflows/verify.yml`。v4 は Node.js 20 で動き、GitHub Actions で非推奨の警告が出る。v5 以降は Node.js 24 で動く。`verify.yml` のコメントにある例も `actions/setup-node@v7`・`node-version: '24'` に揃えた。README の該当する記述も合わせた。

### 移行
- 更新前の台帳（`lstart` の cksum のキー）に書かれた登録は、キーが一致しないため失効として扱う（誤って止める側には倒れない）。更新したあとは、動いているセッションも新しい識別子（`pid-<PID>-<新しいキー>`）の台帳ファイルへ書く。更新の直後は、それまでの登録（着手した issue など）が他のセッションから見えなくなるので、必要なら `scripts/session-ledger.sh claim issue <番号>` で登録し直してください。
- 生成済みの workflow は `--upgrade` で追従できる（手を入れていれば `.dcb-new` が置かれる）。手で直す場合は `actions/checkout@v4` を `@v7` へ書き換えてください。セルフホストのランナーでは、Actions Runner v2.327.1 以降が要る。

## v0.15.0

### Summary
- **この版が要求する ai-playbook は v0.5.0 以降のまま**（新しい雛形を要求しない。雛形は 15 種のまま）。台帳の手順を持つ `/intake` と `/land` の雛形、16 章「セッション間の協調」、`AGENTS.md` の例示は ai-playbook v0.7.0 に入っているので、`--playbook-version v0.7.0` を勧める。
- **共有台帳とセッション協調フックの解放を、呼び出しごとに行うようにした**（ojos/ai-packages-dev#425）。台帳の登録に任意の「呼び出しの識別子」（8 列目。`claim` / `release` の `--call <ID>`）を持たせ、識別子付きの解放はその識別子の登録だけを外す。フックは `tool_use_id` を渡すため、同じセッションが同じ種類の操作を並行しても先に終わった呼び出しが他方の登録を外さず、複合コマンドが拒否されたときに先行する登録を外すこともない。衝突の判定は従来どおり（種類・作業ツリーの単位）。識別子を渡さない使い方と、7 列の古い台帳ファイルは従来どおり動く。フックの冒頭と README に書いていた 2 件の限界を外した。
- **並行セッションの共有台帳 `scripts/session-ledger.sh` を生成物へ足した**（ojos/ai-packages-dev#395）。同じホストで並行して動く AI セッションが、issue・文書・マージ/リリース・作業ツリーの git 操作・重いゲートを `claim` で登録し、`check` で衝突を確かめる。置き場所は `git rev-parse --git-common-dir` の配下で、セッションごとに別ファイルへ追記する。持ち主の PID が消えた登録と、更新が止まった登録は失効する。台帳は実行環境に依存しないので、`--with-*` に関わらず常に生成する。フックと settings.json の配線は、下の「セッション協調フック」の項目。
- **セッション協調フック `scripts/session-coord-hook.sh` を `--with-claude` で生成する**（ojos/ai-packages-dev#395）。`.claude/settings.json` の hooks に SessionStart・PreToolUse（Bash と Edit|Write）・PostToolUse（Bash）・SessionEnd の配線を足した（既存の `confirm-merge-hook.sh` の配線は PreToolUse の先頭に残る）。SessionStart は他のセッションの登録を要約して表示する。PreToolUse の Bash は、マージ・リリース（`gh pr merge`・`gh release`・merge エンドポイントへの PUT・`mergePullRequest`）、同じ作業ツリーでの git 操作（checkout / switch / rebase / reset / fetch など）、重いゲート（`verify.sh` / `loop-gate.sh`）の同時起動を拒否し、同じ issue へのブランチ作成での着手を警告する。Edit|Write は他のセッションが登録している文書を警告する。拒否・警告には相手の識別子・登録の種類・調整の手順を添える。台帳の読み書きに失敗したときは警告して通す。マージ・git 操作・ゲートは実行のあいだだけ登録し（PreToolUse で登録、PostToolUse で解放）、issue はブランチ作成で登録して SessionEnd で解放する。セッションの識別子は台帳の既定（祖先で最初のシェル以外のプロセス）で、フックと Bash のコマンドで揃うことを実機で確認した。既存の `.claude/settings.json` は温存されるため、README の hooks を手で足す。
- **台帳に `refresh` を足した**（ojos/ai-packages-dev#395）。自分の生きている登録を、最後の更新から 5 分以上たっていれば claim し直して更新時刻を新しくする。長いセッションの登録が失効（既定 8 時間）しないよう、フックが PreToolUse のたびに呼ぶ。
- 同梱の `/intake` と `/land` のスキル雛形（ai-playbook 側）が、着手のときの `claim issue`、マージの前の `check merge`、作業の終わりの `release` を手順に持つ。
- **`scripts/check-doc-links.sh` が、括弧を含むリンク先（例: `docs/foo(bar).md`）を最初の `)` で切らず、1 つのリンク先として検査するようにした**（ojos/ai-packages-dev#415）。タイトルや `<...>` の中の括弧は数えず、対応が取れないときは従来どおり最初の `)` で切るため、従来検査できていたリンクを漏らさない。
- **README「資格情報の扱い」に、fine-grained PAT の権限の例を足した**（ojos/ai-packages-dev#416）。Checks は fine-grained PAT では選べず、非公開リポジトリでは `check-runs` と `gh pr checks` が 403 になる。同梱の `/land` スキル（ai-playbook の雛形）は、Actions と Commit statuses の権限だけで CI を待つ。
- **規範を置くとき、入口ファイルに `AGENTS.md` を加えた**（ojos/ai-packages-dev#397）。Codex など `AGENTS.md` を読む実行環境が、規範の入口から 3 層構造へたどれる。`CLAUDE.md` / `.github/copilot-instructions.md` と同じ雛形（`templates/entry.md`）の写しで、既存の `AGENTS.md` は `--playbook-conflict-policy` に従う。`--without-playbook` など規範を置かない生成では作らない。由来記録（`.devcontainer/ORIGIN`）のハッシュの記録の対象にも含まれる。
- README に、実行環境ごとの対応範囲の表を足した。機構（スキル・委譲先エージェント・フック）は Claude Code 向けだけで、この方針は変わらない。
- **`bootstrap.sh --upgrade` を追加した**（ojos/ai-packages-dev#396）。生成したプロジェクトが、1 コマンドで新しい版の DCB の生成物と規範へ追従できる。`.devcontainer/ORIGIN` に記録した入力で生成し直し、引数で渡したものだけを上書きする。対象は DCB 自身のテンプレートと、規範経由で置くファイル（規範本体・入口ファイル・`.ai-playbook/VERSION`・第二意見のスクリプトなど）の両方。
- ファイルごとの振り分け: 手を入れていない（現物 = 記録したハッシュ）なら新しい版で更新する。手を入れた（記録の無い現物も含む）なら上書きせず `<path>.dcb-new`（モードは元のファイルに揃える）を隣へ置き、差分の要約を出す。新しい版で増えた分は生成する。新しい版で生成されなくなった分は報告だけして削除しない。手を入れたが新しい版と同じ内容なら更新済みとして扱う。手を入れたファイルは自動では混ぜない。`.dcb-new` が取り込み待ちの印になる。
- 終了コードは、全件適用 = 0、`.dcb-new` を残した = 2、失敗 = 1。`--upgrade --dry-run` は計画だけを出して何も書かない。`--upgrade` と `--force` は同時に指定できない（エラー）。出力先の既定は現在のディレクトリ。生成先のシンボリックリンクはたどらず、手を入れた扱いにする。
- 注意: `--with-*` は足せるが外せない（外すときは生成し直す）。生成されなくなったファイルは報告するだけで削除しない。規範の取得元が `local`（ローカルのパス）の場合は、記録していないため `--playbook-from` の明示が要る。追従先は実行した `bootstrap.sh` の版で、最新版をネットワークへ問い合わせない。
- **`.devcontainer/ORIGIN` に、生成結果を左右する入力と、規範経由のファイルのハッシュを記録するようにした。** 既存の行（`version=` / `flags=` / `hash:<path>=`）は変えず、`inputs-format=1` と `input:<名前>=<値>` の行を足す。記録する入力は `--project-name` / `--languages` / `--base-image` を指定したか（指定しなければ `auto`）と、その値 / `--no-gitignore`・`--gitignore-targets` / 規範を置いたか・取得元の種類（`tag` / `url` / `local` / `adjacent`）。値の中の改行・`%` だけを `%0A` / `%0D` / `%25` へ置き換えるので、カンマ・空白・`=` を含む値も読み戻せる。規範経由で置くファイル（`.ai-playbook/**` の規範本体と `VERSION`）のハッシュも記録対象に加えた。
- **ローカルのパスは ORIGIN へ書かない**（ORIGIN からは利用側リポジトリへ絶対パスが残らない）。`--playbook-from` が URL のときだけ値を残すが、`@` `?` `#` を含む URL（資格情報や署名を含みうる）は書かない。`--playbook-conflict-policy` / `--force` / `--dry-run` / `--output-dir` は生成結果を決める入力ではないので記録しない。
- **`.ai-playbook/VERSION` と ORIGIN の役割を分けた。** `VERSION` は規範の取得元（どのタグ・どこから取り込んだか。`version=` / `source=`）の記録で、従来どおり残る（`source=` にはローカルのパスが残る）。ORIGIN は生成の入力と現物のハッシュの記録。
- **`doctor.sh` が、残っている `*.dcb-new` を WARN で一覧し、取り込み方（中身を見て手で混ぜてから `.dcb-new` を消す）を出す。** あわせて ORIGIN の書式を検査する。認識できない行・不正な値・入力の必須の行の欠落は FAIL にする。新しい形式（`inputs-format=1`）では `version=` と `flags=` を必須にし、同じ `input:` の名前の重複も FAIL にする。入力の行が無い古い ORIGIN は、今までどおり読める。
- **`--upgrade` を付けない再実行・`--force`・規範の配置が、生成先のシンボリックリンクをたどって出力先の外へ書かないようにした**（ojos/ai-packages-dev#418）。切れたリンクを含め「既存のファイルがある」として扱う。既定（skip）は温存して報告し、`--force` / `--playbook-conflict-policy overwrite` はリンク自体を通常ファイルで置き換える（リンク先は触らない）。生成先の親ディレクトリの実体が出力先の外なら、何も書かずにエラー（終了コード 1）で止める。リンクでない生成先の挙動は変わらない。
- **既存フラグの挙動は変わらない。** `--upgrade` を付けない再実行と `--force` は従来どおり。既存の生成先に規範が入っていて `.ai-playbook/**` を温存した再実行では、ORIGIN を作らない（温存したファイルの由来を保証できないという従来の規則が、`.ai-playbook/**` にも及ぶ）。
- `--upgrade` の記録が無い生成先で、必須の引数（`--project-name` / `--languages`）を明示したときは、`error:` ではなく `note:` の 1 行だけを出して続ける。引数が足りないときだけ、`error:` と案内を出して止まる。

### 移行
- 規範を置いて再生成すると、リポジトリ直下に `AGENTS.md` が増える。既に独自の `AGENTS.md` がある場合は、既定ポリシー（`skip`）で温存される。
- **既存の生成先が `--upgrade` で追従できるようになる。** 初回だけ、記録の状態に応じた準備が要る。
  - ORIGIN に `inputs-format=1` がある（この版以降で生成した）生成先: 生成先のディレクトリで `bash bootstrap.sh --upgrade --dry-run` を実行して計画を確かめ、`--dry-run` を外して実行する。引数は要らない。ただし、規範の取得元が `local` や `@` `?` `#` を含む URL の生成先は、`--playbook-from <path|url>` を付ける。
  - 古い ORIGIN（`inputs-format` が無い）、または ORIGIN が無い生成先: 記録から入力を再現できないので、**引数を明示した初回の `--upgrade` が要る。** `--project-name` / `--languages`（必須）と、使っていた `--with-*`・`--base-image`・規範の取得元を、生成時と同じに指定する。この実行で ORIGIN が新しい形式で書き直され、以後は引数なしで追従できる。
  - 古い ORIGIN は規範経由のファイル（`.ai-playbook/**` など）のハッシュを持たないことがある。記録の無いファイルは、新しい版と内容が違えば「手を入れた」扱いになり、`.dcb-new` が置かれる。見比べて取り込み、`.dcb-new` を消す。残っていると終了コードは 2 になり、`doctor.sh` が WARN で知らせる。

## v0.14.0

### Summary
- **`LOOP_GATE_REVIEW_CMD` で第二意見を差し替えても、レビューしていないものを通さず、記録もしないようにした**（ojos/ai-packages-dev#402）。差し替えた経路は commit 済み範囲への切り替えを通らず、空のステージ済み差分を見て「対象なし」で 0 を返したまま GATE_PASS と scope=staged の記録が出ていた（確認側も緑になる）。解決した範囲を環境変数 `LOOP_GATE_REVIEW_RANGE` で渡すようにし、レビュー対象が実在するのに差し替えたコマンドが「対象なし」と出力したときは GATE_FAIL とし記録も残さない。レビュー対象が本当に無いと解決したときは、差し替えたコマンドを実行せず、記録なしで通過する。
- **devhost を新設し、DCB のリリースに同梱した**（ojos/ai-packages-dev#375 / ojos/ai-packages-dev#376）。SSH で届く外部の機械（自宅のラップトップ、社内のサーバーなど）の上で devcontainer を起こしたまま保ち、スマホやほかの端末から入って AI コーディングを続けるための道具一式 `devhost/`。bootstrap.sh が生成するものではなく、利用者が外部の機械へ手で置く独立した道具だが、配布は DCB のリリースの `PACKAGE_ARCHIVE.tar.gz` に `devhost/` として同梱する。個別の Release 資産（`SHA256SUMS` の対象）には加えず、完全性は `PACKAGE_ARCHIVE.tar.gz` のハッシュ（`RELEASE-MANIFEST.json`）で守る。導入手順は README の「devhost」の節と、同梱された `devhost/README.md` を参照。**devhost を同梱した最初の版。**
- **`--with-codex` の生成物で、codex のサンドボックスが動くようにした**（ojos/ai-packages-dev#392）。`compose.yaml` の `app` に `security_opt: [apparmor=unconfined, seccomp=unconfined]` を入れる。Docker の既定の seccomp が bwrap の namespace の作成を止め（ネイティブ Linux の Docker Engine でも Docker Desktop でも）、ネイティブ Linux ではさらに AppArmor の `docker-default` が mount を止めていた。**AppArmor だけ外しても動かない。** `--with-codex` を付けない生成物には入らない。
- **この版が要求する ai-playbook は v0.5.0 以降のまま**（新しい雛形を要求しない）。第二意見の判定で「差分を読めなかった回答」を落とす修正（ojos/ai-packages-dev#386）は ai-playbook v0.6.0 に入っているので、`--playbook-version v0.6.0` を勧める。
- 機能追加と修正のみ。**既存フラグの挙動は変わらない**（`--with-codex` の生成物に `security_opt` が増える）。

### Highlights
- **取り込み元の対処は、たまたま足りていた（ojos/ai-packages-dev#392）**: 取り込み元（game-forge）は AppArmor だけを外して動いていたが、seccomp は Go の devcontainer feature（Go のデバッガのため）がすでに外していた。Ubuntu 26.04 のネイティブの Docker Engine と codex 0.160.0 で、既定・AppArmor だけ・両方の 3 通りを実測し、両方が要ることを確かめた。`systempaths=unconfined` は要らない（codex は `/proc` の mount の失敗を自分で避ける）。代償（コンテナの中で namespace の作成と mount ができるようになる）は README の「コンテナの中での codex のサンドボックス」に書いた。

### 移行
- **devhost は既存の生成物に影響しません。** bootstrap.sh の生成物に含まれず、既存の devcontainer 構成を変更しません。
- **以前の版で `--with-codex` を付けて生成した構成では、codex のサンドボックスが bwrap のエラーで失敗します**（`bwrap: No permissions to create new namespace`）。再生成するか、`.devcontainer/compose.yaml` の `app` に次の 3 行を足して、コンテナを作り直してください（Rebuild Container）。

  ```yaml
      security_opt:
        - apparmor=unconfined
        - seccomp=unconfined
  ```

## v0.13.0

### Summary
- **devcontainer のベースイメージを版の名前で固定した**（ojos/ai-packages-dev#368）。候補を浮動のタグ（`base:ubuntu` / `base:debian`）から **`base:noble`（Ubuntu 24.04）/ `base:bookworm`（Debian 12）** へ変えた。`base:ubuntu` は 2026-09-10 に 26.04 を指すようになり、26.04 には `apt-key` が無いため、**`--with-gcp` が入れる google-cloud-cli の feature が exit 127 で落ちる。** 古いイメージのキャッシュを持たない環境で新しくビルドしたときだけ表に出る。os/arch の自動判定と `--base-image` の上書きはそのまま。
- **第二意見の記録と確認側を配置するようにした**（ojos/ai-packages-dev#361 / ojos/ai-packages-dev#363）。規範を配置する構成（`--with-playbook` / `--playbook-version` / `--playbook-from`）では、第二意見と一緒に `scripts/second-opinion-record.sh` / `scripts/second-opinion-gate-exempt.sh` / `.github/workflows/second-opinion-gate.yml` / `scripts/second-opinion-schema.json` を置く。`loop-gate.sh` は第二意見の出力を記録し、push の後に `bash scripts/second-opinion-record.sh post` で PR へ投稿する運用になる。
- **`--with-codex` を足した**（ojos/ai-packages-dev#362）。Codex CLI の導入（0.156.0 未満なら入れ替える）、`~/.codex` の永続化、`.env.example` の第二意見のエンジンの記入欄。付けない生成物には codex 関連の行を出さない。
- **identity-guard が squash merge で GitHub の付ける co-author を許可するようにした**（ojos/ai-packages-dev#369）。マージした人と PR の作者が違うと（Dependabot の PR など）、GitHub はマージの瞬間に作者の `Co-authored-by: <login>@users.noreply.github.com` を足す。co-author を許可リストとしか照合していなかったため、**`push(main)` の全履歴検査が以後ずっと赤になっていた。** 判定を確かめる自己試験 `scripts/verify-commit-identity-selftest.sh` を配り、`identity-guard.yml` が検証の前に回す。
- **文書の相対リンクの検査 `scripts/check-doc-links.sh` を配るようにした**（ojos/ai-packages-dev#371）。追跡している Markdown の相対リンクが、追跡ファイルとして実在することを見る。除外は `DOC_LINKS_EXCLUDE`（コロン区切り。既定は空）。既存の衛生検査と同じく、呼び出しはプロジェクト側で配線する。
- **`loop-gate.sh` のレビュー範囲から、他の PR を取り消す差分を除いた**（ojos/ai-packages-dev#382）。上流が分岐点より先へ進んでいるときは、起点を分岐点の SHA にする。ゲートの最中に既定ブランチが進むと、`git diff` が両端の差を取るため、既定ブランチに新しく入った変更を打ち消す差分が範囲に混ざり、触っていないファイルへの指摘で落ちていた。
- **ネイティブ Linux の Docker での UID の食い違いの扱いを README に書いた**（ojos/ai-packages-dev#372）。生成物は変えない（下記）。
- **この版は ai-playbook v0.5.0 以降を要求する**（`second-opinion-record.sh` / `second-opinion-gate.yml` / `second-opinion-gate-exempt.sh` / `second-opinion-schema.json` の 4 雛形が必要）。
- 機能追加と修正のみ。**既存フラグの挙動は変わらない**（ベースイメージの既定値は変わる）。

### Highlights
- **浮動のタグは上流の都合で動く（ojos/ai-packages-dev#368）**: 浮動のタグかどうかは、イメージ名に結びつけずタグの形（タグ無し・`latest`・`ubuntu`・`debian`）で判定し、テストで固定が崩れないことを見る。Debian も実ビルドで選んだ（`base:debian` が指す trixie は同じ `apt-key` の欠落で落ち、bookworm は通る）。**版を上げるときは、features がすべて新しい版で入ることを確かめてから。**
- **`updateRemoteUserUID` は compose 方式でも効く（ojos/ai-packages-dev#372）**: 取り込み元は「`updateRemoteUserUID` は dockerComposeFile 方式には効かない」を前提に、ビルド引数で UID を付け替える仕組みを持っていた。**devcontainer CLI 0.89.0 の実装と、UID 1001 の利用者での実測で、この前提が成り立たないことを確かめた**（コンテナの `vscode` が `uid=1001 gid=1001` になる）。生成物は変えず、`false` にしないこと、効かない構成（CLI が macOS / Windows で動き、Docker だけが遠くの Linux にある場合）を README に書き、無効化をテストで止める。
- **判定の自己試験は、落ちるべき形を見せる（ojos/ai-packages-dev#369）**: 本物の履歴だけでは、落ちるべき形も「何でも通る」状態もほとんど現れない。1 コミットだけの仕込みのリポジトリで、通る 5 形と落ちる 6 形を確かめる。許可は committer が `noreply@github.com` のコミットに縛ったままで、ローカルで作ったコミットには広げない。
- **リンクは追跡ファイルの集合で判定する（ojos/ai-packages-dev#371）**: GitHub が配るのは追跡ファイルだけなので、作業ツリーにだけあるファイルへのリンクは手元では開けても公開された文書では 404 になる。パスは正規化し、リポジトリの外へ出るリンクは不合格にする。タイトル付きのリンク（リンク先の後ろに引用符でタイトルを書く形）はリンク先だけを見る。

### 未確認の事項
- 本物の codex CLI での実行（`--with-codex` の導入と永続化は、生成物のテストで確かめている）
- Dependabot の PR で `second-opinion-gate.yml` が status を書けること（GitHub の文書に基づく判断で、実地では確かめていない）

### 移行
- **既存の生成物は再生成しない限り無影響です。** ただし、**既存の生成物のベースが `base:ubuntu` のままだと、新しくビルドしたときに `--with-gcp` の feature が落ちます。** `.devcontainer/compose.yaml` の `image:` を `mcr.microsoft.com/devcontainers/base:noble` へ書き換えるか、再生成してください。
- 再生成すると、次が増えます。
  - 規範を配置する構成のとき: `scripts/second-opinion-record.sh` / `scripts/second-opinion-gate-exempt.sh` / `scripts/second-opinion-schema.json` / `.github/workflows/second-opinion-gate.yml`
  - `scripts/verify-commit-identity-selftest.sh`（`identity-guard.yml` が呼ぶ）
  - `scripts/check-doc-links.sh`
  - `--with-codex` 指定時のみ、Codex CLI の導入と `~/.codex` の永続 volume
- **第二意見の記録と確認側を使う場合は、push のたびに `bash scripts/second-opinion-record.sh post` を実行します。** 記録は head SHA に紐づくため、直して push するたびに打ち直します。確認側は required check ではありません。
- **ai-playbook は v0.5.0 以降を指してください。** それより古い版には雛形 4 本が無く、生成時に停止します。

## v0.12.0

### Summary
- **移植性の静的検査を配布物へ入れた**（ojos/ai-packages-dev#330 / ojos/ai-packages-dev#332 / ojos/ai-packages-dev#343 / ojos/ai-packages-dev#346）。`scripts/check-shell-portability.sh` が「この環境では通るが BSD 系（macOS）では落ちる」綴りを、実行せずに検出する。対象は追跡している `*.sh` と `*.md` のフェンス内で、**`tests/` も検査自身も除外しない。**
- **衛生検査 2 本を配布物へ入れた**（ojos/ai-packages-dev#327）。`check-control-chars.sh`（読めない制御文字）と `check-table-breaks.sh`（Markdown の表崩れ）。**読んでも気づけない壊れ方を機械で落とす。**
- **`npm ci` 忘れの検出を入れた**（ojos/ai-packages-dev#334）。`--languages node` を選んだときだけ配る。`package-lock.json` と `node_modules` の記録が食い違う状態を落とす。
- **マージ確認フックを配り、迂回経路を 3 件塞いだ**（ojos/ai-packages-dev#312 / ojos/ai-packages-dev#315 / ojos/ai-packages-dev#318 / ojos/ai-packages-dev#320）。`gh pr merge` をコマンド位置で検知して確認を挟む。制御語の前置による迂回、同一行の別コマンドでの誤検知、squash 本文の CI 抑止の綴りによる main の CI 不起動を塞いだ。
- **PR 確認からマージまでの手順（`land` スキル）を配るようにした**（ojos/ai-packages-dev#311）。`--with-claude` 指定時のみ。
- **生成物の由来を記録し、`doctor.sh` が配布物との乖離を診断するようにした**（ojos/ai-packages-dev#321）。
- **ローカル事前ゲートが commit identity を見るようにした**（ojos/ai-packages-dev#302）。検知が push 後になる経路を塞いだ。
- **README の保証範囲を訂正した**（ojos/ai-packages-dev#339）。**v0.11.0 までの README は「`SHA256SUMS` は改ざんを検出する」と書いていたが、これは誤りである**（下記）。
- **リリース資産へ artifact attestation を発行するようにした**（ojos/ai-packages-dev#340）。**この版から効く。**
- **この版は ai-playbook v0.4.0 以降を要求する**（`review-usable.sh` / `check-review-usable.sh` / `claude-skill-land.md` の 3 雛形が必要）。
- 機能追加と修正のみ。**既存フラグの挙動は変わらない。**

### Highlights

- **`SHA256SUMS` は改ざんを検出しない（ojos/ai-packages-dev#339）**: `SHA256SUMS` はスクリプトと同じリリースから同じ経路で取得するため、**リリースを書き換えられる立場なら両方を同時に差し替えられる。** 守れるのは取得の破損・途中切断と、公開物どうしの食い違いまでである。**v0.11.0 までの README はこれを誤って約束していた。** 記述を守れている範囲へ直した。
- **attestation は「気づける」ようにするだけである（ojos/ai-packages-dev#340）**: `SHA256SUMS` に SLSA provenance が付き、検証すればリリース資産だけの差し替えに気づける。**ただしワークフローを実行できる立場なら正規の attestation を作れる。** 信頼の起点が「リリースの内容」から「リポジトリへの書き込みの完全性」へ移るだけで、脅威が消えるわけではない。検証手順は README にある（**任意の追加手順**。導入手順は `curl` とチェックサム実装だけで閉じたまま。実装は `command -v` で `sha256sum` / `shasum -a 256` へ分岐する）。
- **導入手順が macOS で落ちていた（ojos/ai-packages-dev#332）**: README が案内する取得の 1 行目に `sha256sum` を使っており、**GNU coreutils 専用のため macOS 利用者はそこで止まっていた。** `command -v` で `shasum -a 256` へ分岐する形へ直した。移植性検査を足したことで見つかった。
- **検査自身も検査の対象に含める（ojos/ai-packages-dev#330）**: 検出対象の綴りをリテラルで持つ層を除外すると、そこに残った本物を見逃す（実際に見逃した）。除外ではなく `# bsd-ok: 理由` の印で通す。**逃げ道の無い検査は、そのうち丸ごと外される。**
- **確認フックは「うっかり」を止める guardrail である（ojos/ai-packages-dev#315 / ojos/ai-packages-dev#320）**: 意図的な迂回は防げない。`--body-file` の中身は読まず、`gh pr merge` 以外の経路（REST / GraphQL）へは検査を広げていない。**保証するのは「黙ってマージしない」ことであって「マージさせない」ことではない。**
- **`awk` の間隔指定は下限 2 以上で食い違う（ojos/ai-packages-dev#343）**: mawk は `^x{2,3}$` に `xxx` を一致させない。**以前この規則を外した根拠は `xx` に一致するという見本で、その入力では区別が付かなかった。** 検出へ戻した。
- **ブラケット式の中の `\n` は「改行以外」ではない（ojos/ai-packages-dev#343 / ojos/ai-packages-dev#346）**: `[^\n]` は「バックスラッシュと `n` 以外」で、`n` を含む行を黙って落とす。sed 側はパターン側だけを見る（置換側にブラケット式は存在しない）。

### 移行

- **既存の生成物は再生成しない限り無影響です。**
- 再生成すると、次が増えます。
  - `scripts/check-shell-portability.sh` / `check-control-chars.sh` / `check-table-breaks.sh`
  - `scripts/confirm-merge-hook.sh` と `.claude/settings.json` への配線
  - `scripts/review-usable.sh`
  - `--languages node` 指定時のみ `scripts/check-deps-installed.sh`
  - `--with-claude` 指定時のみ `.claude/skills/land/SKILL.md`
- **移植性検査は既存のコードを赤にすることがあります。** 追加直後は出た指摘を棚卸ししてください。意図的に使う場合は該当行へ `# bsd-ok: 理由` を書きます（理由は必須）。
- **`ai-playbook は v0.4.0 以降を指してください。`** それより古い版には雛形 3 本が無く、生成時に停止します。
- **README の入手手順が変わりました。** `sha256sum` を直接使う形から `command -v` で分岐する形になっています。**macOS で以前の手順が止まっていた場合は、新しい手順を使ってください。**

## v0.11.0

### Summary
- **委譲先エージェント定義を生成物へ配布するようにした**（ojos/ai-packages-dev#259）。`--with-claude` を指定したときだけ `.claude/agents/explorer.md` と `.claude/agents/implementer.md` を置く。雛形は規範パッケージが持ち、本スクリプトは置き先だけを決める（intake 起点スキルと同じ経路）。
- 目的は**モデルとツールを実行環境が読む機構で固定すること**。指示文による呼びかけは迂回できるが、frontmatter は迂回できない。読み取り専用ロールからは編集系ツール（`Edit` / `Write` / `NotebookEdit`）を外す。
- **この版は ai-playbook v0.3.0 以降を要求する**（雛形と、判定の導線を定めた規範の 13 章が必要）。
- 機能追加のみ。既存フラグの挙動と、`--with-claude` 以外の生成物は変わらない。

### Highlights

- **定義だけでは役割は使われない（ojos/ai-packages-dev#259）**: 委譲判定に導線が無ければ、定義があっても選ばれることが構造的に無い。導線は規範側（`shared-ai-rules.md` の「実装委譲パターン」）が持ち、生成物のテストは**規範側に導線が実在すること**まで検査する。
- **`tools` の制約は完全ではない**: 調査に必要なコマンド実行を残す以上、リダイレクトを経由した書き込みは塞げない。機構で保証されるのは編集系ツールの除外までで、そこから先は指示による制約である。この但し書きは各定義に書いてある。
- **既存の生成先は上書きしない**: 衝突ポリシーは既定 `skip`。すでに `.claude/agents/` を持つプロジェクトは影響を受けない。
- **`model` の脱落を検査する**: `model` の記述が落ちた定義は親のモデルを継承し、機構としての意味を失う。落ちたことは実行するまで分からないため、生成物のテストで `inherit` と未指定を落とす。

### 移行

- 既存の生成物は再生成しない限り無影響です。
- 再生成すると、`--with-claude` 指定時に `.claude/agents/` の 2 ファイルが増えます。既存ファイルがあれば `skip` されます。
- **ai-playbook は v0.3.0 以降を指してください。** それより古い版には雛形が無く、生成時に停止します。

## v0.10.1

### Summary
- **macOS で規範を配置する構成が使えなかった不具合を修正した**（ojos/ai-packages-dev#285）。`--with-playbook` / `--playbook-version` / `--playbook-from` のいずれを指定しても `error: no rule files found in playbook source` で停止していた。**取得も展開も成功しており、壊れていたのは最終の存在検査だけ**だった。
- 原因は `set -o pipefail` 下で `find … | grep -q .` としていたこと。`grep -q` は最初のマッチで終了してパイプを閉じ、まだ書き込み中の `find` が SIGPIPE で死ぬ。パイプライン全体が非 0 になり、**`grep` が実際にはマッチしているのに「0 件」と判定される**。
- **Linux では再現しない。** GNU find は EPIPE を握って終了コード 0 で終わるが、BSD find（macOS）は SIGPIPE で 141 を返す。
- 修正は `find … -print -quit` で**パイプ自体を無くす**形にした。1 件見つけた時点で `find` 自身が正常終了する。

### Highlights

- **`grep` は成功していた（ojos/ai-packages-dev#285。実測）**: `PIPESTATUS=141 0` — 右（grep）は 0 でマッチしている。左（find）だけが SIGPIPE で死んでいた。同じ木に対し `| wc -l` は 23 件を返す（`wc` は EOF まで読むので早期クローズが起きない）。
- **同じ罠を一度踏んでいた（ojos/ai-packages-dev#285）**: 同一関数内の別の `find … | head -n 1` には既に `|| true` が付いていた。今回直した 2 箇所はその取りこぼしで、**部分的な対処が「塞いだ」ように見えていた**。
- **`|| true` では直さない（ojos/ai-packages-dev#285）**: 症状は消えるが、生産側が**本当に失敗した**場合まで握り潰す。「検査が成立していないことを合格にしない」に反する。
- **`-quit` は BSD find でも使える（ojos/ai-packages-dev#285。実測）**: このリポジトリに前例が無い構文だったため、GNU の挙動を普遍と仮定せず macOS 実機で検証した（`rc=0`、多数の一致がある木で 1 行のみ出力 = `-quit` が機能した証拠）。FreeBSD find(1) にも primary として記載がある。
- **Linux でしか走らないテストでは捕まえられない（ojos/ai-packages-dev#285）**: 実行して再現する検査は緑になってしまう。同型の再混入は静的検査で落とす（開発リポジトリ側の機構で、配布物には含まれない）。

### 移行

- **`--with-playbook` 系を macOS で使っていた場合、v0.10.1 へ上げてください。** v0.10.0 以前では規範を配置する構成が成立しません。
- Linux では v0.10.0 と挙動が変わりません。
- 生成物には影響しません。修正は `bootstrap.sh` 自身の判定で、生成されるファイルは変わりません。

## v0.10.0

### Summary
- **Antigravity CLI（`agy`）を選べるようにした**（ojos/ai-packages-dev#271）。`--with-antigravity` を新設し、CLI の導入・永続化・テレメトリ無効化を配線する。ai-playbook v0.2.0 が配布した `scripts/second-opinion-review.sh --engine antigravity` は、これまで生成物では選んでも動かなかった。**機能追加のみで、既存の生成物と既存フラグの挙動は変わらない。**
- **`--with-gemini` には束ねていない**（ojos/ai-packages-dev#271）。認証手段が違う（API キー / OAuth）ため、片方だけ使う構成を機構で表現できるようにする。束ねると使わない CLI が必ず入る。
- **永続 volume は `gemini` と共有する**（ojos/ai-packages-dev#271）。`agy` は資格情報を `~/.gemini/antigravity-cli/` に置くため、`--with-gemini` / `--with-antigravity` の**どちらか一方でも指定すれば `/home/vscode/.gemini` の named volume が 1 つだけ**作られる。両方指定しても重複しない。
- **テレメトリを既定で無効化する**（ojos/ai-packages-dev#271）。`~/.gemini/antigravity-cli/settings.json` の `enableTelemetry` を `false` へマージする。冪等で非破壊、`jq` 不在と壊れた JSON では非 0 で停止する。**無効化されるのは CLI のみで、Antigravity IDE は別設定。**
- `--with-antigravity` 指定時のみ、`.env.example` へ第二意見のエンジン選択欄（`SECOND_OPINION_ENGINE`）が入る。

### Highlights

- **volume は名前まで共有する（ojos/ai-packages-dev#271）**: ディレクトリだけ共有して名前を分けると、`--with-antigravity` 単独で作った `antigravity-storage` に対し、あとから `--with-gemini` を足した構成が `gemini-storage` を見に行く。同じ場所を指しているのに別 volume へ切り替わり、**ログイン状態が消えたように見える**。名前も `gemini-storage` に寄せた。
- **重複は機構で潰す（ojos/ai-packages-dev#271）**: volume 生成の条件が「単一フラグ → 単一ディレクトリ」から外れる唯一の例外。重複したまま流すと定義・マウント・所有権修復・実マウント検査がすべて 2 行ずつになり、**compose は同じ名前の volume を 2 回定義した時点で落ちる**。併用構成で各行が 1 本であることを回帰テストで固定した。
- **`agy` は npm 配布ではない（ojos/ai-packages-dev#271。実測）**: `install_if_missing <cmd> <npm-pkg>` の同型に乗らず、配布元のインストーラを取得して `~/.local/bin/agy` へ置く。インストーラが 0 で終わりながらバイナリを置かない経路があるため、実体の有無で「PATH に無いだけ」と「置かれていない」を分け、後者は非 0 で止める。
- **テレメトリのオプトアウトは設定ファイルしか手段が無い（ojos/ai-packages-dev#271。実測）**: `AGY_*` にテレメトリ系の環境変数は無く、`DO_NOT_TRACK` も非対応（agy 1.1.11 のバイナリを実測）。`settings.json` は `agy` 自身も書く（`colorScheme` / `trustedWorkspaces` 等）ため、上書きではなくマージする。
- **`jq` の `//` は false も代替側へ落とす（ojos/ai-packages-dev#271）**: `.enableTelemetry // empty` で判定すると「既に false」を「未設定」と誤り、毎回書き込みが起きる。値を直読みする。
- **雛形の地の文へ装備名を列挙しない（ojos/ai-packages-dev#271）**: ヒアドキュメント内は構成によらず生成物へ入るため、フラグ名を列挙すると選ばれていない装備の名前が残る。「そのフラグを指定しなければ関連する記述が 1 行も入らない」を、生成物ツリー全体の検査で担保している。

### 移行

- **既存の生成物は、再生成しない限り影響を受けない。** 追加されたのはフラグ 1 つで、既存フラグの挙動は変わらない。
- `--with-antigravity` を使う場合、**`agy` は OAuth のみ**で API キーに対応しない。導入だけでは使えず、コンテナ内で対話的に `agy` を起動して初回ログインを済ませる必要がある。
- 既に `--with-gemini` で生成済みのプロジェクトへ `--with-antigravity` を足して再生成しても、**volume 名は `gemini-storage` のままなので既存のログイン状態は保持される。**

## v0.9.1

### Summary
- **この版は ai-playbook v0.2.0 以降を要求する。** 第二意見レビューの雛形が `gemini-review.sh` から `second-opinion-review.sh` へ改名されたため（ojos/ai-packages-dev#268）、生成器は新しい名前を規範パッケージから解決する。**古い規範パッケージを指すと、生成時にエラーで停止する**（雛形が見つからない）。生成される `loop-gate.sh` も新しい名前を呼ぶ。
- **機密混入検査を配布スクリプト `scripts/check-no-secrets.sh` として切り出した**（ojos/ai-packages-dev#239）。共通規範「機密をコミットしない」の機械化で、生成される `verify.sh` から直接呼ぶ。追跡前（追跡対象へ入る前に落とす）と追跡済み（CI で落とす）の 2 経路に加え、`.env.example` の値検査とキー整合の計 4 検査。
- **その機密検査が、パス名に改行を含むファイルを両経路で取りこぼしていたのを塞いだ**（ojos/ai-packages-dev#263）。列挙を NUL 区切りへ変更（`git ls-files -z` / `git status --porcelain -z`）。
- **マージ実行に確認を挟む PreToolUse フックを配布する**（ojos/ai-packages-dev#241。`--with-claude` 連動）。規範 `closer.md` が定める既定の merge 方針（手動承認）を、呼びかけではなく機構で担保する。
- **`verify.sh` を CI で回すワークフロー雛形を追加した**（ojos/ai-packages-dev#238）。両利用プロジェクトが独立に同じものを作っており、配布物の欠落だった。
- **`.env` の `GH_TOKEN` で gh 認証を PAT に固定できるようにした**（ojos/ai-packages-dev#237）。複数アカウント運用でトークンが互いに失効する問題への対処。
- **`review-gate.yml` の誤判定を timeline で塞いだ**（ojos/ai-packages-dev#235）、**生成物が素で shellcheck を通るようにし、回帰テストと shellcheck の常時装備を追加した**（ojos/ai-packages-dev#236。`load-project-env.sh` の SC2296 が severity error だった）、**`.gitignore` 管理セクションへ Claude 生成物と Terraform を追加**（ojos/ai-packages-dev#240）、**`loop-gate.sh` のレビュー範囲がベースブランチ取り込みで汚染される問題を修正**（ojos/ai-packages-dev#242）、**`setup-git-identity.sh` が system スコープの credential.helper を可視化するようにした**（ojos/ai-packages-dev#243）、**雛形の `--with-copilot` 参照を現行へ直しフラグ名を機械照合するようにした**（ojos/ai-packages-dev#245）。

### Highlights

- **機密検査は `acceptance.sh` 雛形へ入れない（ojos/ai-packages-dev#239）**: あちらはプロジェクトが所有・編集する設計で、受け入れ条件を書き足すたびに触られる。規範由来の検査をそこへ置くと、書き換えのたびに検査が消える経路ができる。`verify.sh` から直接呼ぶ。
- **検査が成立していないことを合格にしない（ojos/ai-packages-dev#239）**: git 管理外での実行、git コマンド自体の失敗、追跡ファイル 0 件は、いずれも「機密が無い」ことを意味しない。すべて失敗として扱う。出力に機密の値は出さない（パスとキー名のみ）。
- **改行を含むパス名は 2 経路とも漏れていた（ojos/ai-packages-dev#263。実測）**: git は行区切りの出力で改行をそのまま出すため、1 パスが 2 行へ割れる。「2 経路で同じ広さに保つ」（ojos/ai-packages-dev#239）は保たれていたが、その広さの外側に穴があった。NUL 区切りへ移すにあたり、`git status --porcelain` の既定が未追跡ディレクトリを `?? dir/` へ畳む点（`--untracked-files=all` で回避）と、改名が 1 レコード 2 パスになる点（`--no-renames` で回避）も塞いでいる。
- **フックは「実行できること」と「実行してよいこと」を分ける（ojos/ai-packages-dev#241）**: 対話中の許可承認によりマージコマンドが技術的に実行可能になった結果、承認を経ないまま PR がマージされた実例がある。ツール実行の前に確認を差し込める機構で担保する。

### 移行

- **ai-playbook を v0.2.0 以降へ上げてから再生成すること。** `--playbook-version` / `--playbook-from` で古い版を指したままだと、雛形が解決できず生成が停止する（ファイルを 1 つも書かずに終了する）。
- 既存の生成物を再生成する場合、`scripts/gemini-review.sh` は新しい名前 `scripts/second-opinion-review.sh` で置かれる。**旧名のファイルは自動では消えない**ので手で削除する。`.env` のキー名の移行も要る（ai-playbook v0.2.0 の「移行」を参照）。
- 再生成しない限り、既存の生成物に影響はない。

## v0.9.0

### Summary
- **破壊的変更。`--with-copilot` からリモートのレビュー機構を分離した**（ojos/ai-packages-dev#230）。`--with-copilot` は手元の開発ツール（CLI・拡張・永続 volume）だけを配線し、リモート最終ゲートのワークフローは新設した `--with-copilot-review` が担う。**`--with-copilot` だけで再生成すると、ワークフローが配置されなくなる**（下記「移行」）。
- **リモート最終ゲートが要求されないまま PR が通る穴を塞いだ**（ojos/ai-packages-dev#222）。要求側 `copilot-review.yml` に加え、要求されたことを別の契機から確認する `review-gate.yml` を配置する。**この版は ai-playbook v0.1.8 以降を要求する**（雛形の供給元が規範パッケージのため）。
- **生成される `verify-commit-identity.sh` が GitHub 由来のコミットを扱えるようになった**（ojos/ai-packages-dev#223）。web UI でのマージやメール非公開設定では author が `<login>@users.noreply.github.com` になり、従来は一律で NG になっていた。あわせて許可エントリにドメイン一括指定を追加した。**許可範囲が広がる挙動変更を含む。**
- **生成される `load-project-env.sh` が git worktree からメインの作業コピーの `.env` へ回り込むようになった**（ojos/ai-packages-dev#227）。worktree は追跡ファイルしか持たず、`.gitignore` された `.env` は複製されない。回り込みが無いと worktree 側でローカル事前ゲート（identity 検査を含む）が使えない。
- 生成される `setup-git-identity.sh` の一時ファイル名に `dcb-` 接頭辞を付けた（ojos/ai-packages-dev#227）。**挙動は不変**で、作成先の名前だけが変わる。

### 移行

**これまで `--with-copilot` + 規範の配置でワークフローを得ていた場合**は、`--with-copilot-review` を足す。それだけで従来と同じ生成結果になる。

```bash
# 従来
bootstrap.sh ... --with-copilot --with-playbook

# 移行後（同じ結果）
bootstrap.sh ... --with-copilot --with-copilot-review --with-playbook
```

- **ローカルの CLI・拡張だけが目的だった場合は、変更は不要。** `--with-copilot` の意味がローカル配線だけに縮んだ形になる。
- **既存の生成物は、再生成しない限り影響を受けない。** 配置済みの `.github/workflows/copilot-review.yml` / `.github/workflows/review-gate.yml` はそのまま残る。`--with-copilot-review` を付けずに `--force` 付きで再生成した場合も、この 2 本は削除されない（生成しないだけ）。ただし規範側の更新が反映されなくなるため、リモート最終ゲートを使い続けるなら新フラグを付けること。
- **`--with-copilot-review` は規範の配置が前提。** `--with-playbook` / `--playbook-version` / `--playbook-from` のいずれも指定せずに（または `--without-playbook` と併せて）指定すると、**ファイルを 1 つも書かずに**エラー終了する。

### Highlights

- **効く場所が違うものを 1 つのフラグで束ねない（ojos/ai-packages-dev#230）**: 分離前は「リモートのレビューゲートだけ欲しい」構成を機構で表現できなかった。ローカル装備とリモート機構は動く場所も前提条件も違う。前者はコンテナ内の開発体験、後者は GitHub 上の PR ゲートで、規範パッケージの雛形を必要とする点も異なる。
- **規範なしの指定は書き込み前に落とす（ojos/ai-packages-dev#230）**: 雛形の解決に任せると、生成物を途中まで書いてから停止する。v0.4.2 で「playbook 取得失敗時に部分生成せず書き込み前にアトミック停止」を選んだ前例に揃え、引数検証の段階で落とす。判定は既存の「規範を配置するか」のロジックを再利用しており、条件を二重に定義していない。
- **要求と確認を分ける（ojos/ai-packages-dev#222）**: `pull_request` の `opened` は配信が取りこぼされることがあり、届かなければ要求側は起動せず、エラーも出ず、他のチェックは緑になる。最終ゲートだけが黙って抜ける。`opened` を見る 2 本目を足しても塞げない（届いていないのはイベント自体）ため、確認側は定期実行を含む別の契機を張る。設計理由の正本は規範パッケージの `review-workflow.md`「要求されたことを別の契機で確認する」。
- **雛形は規範パッケージが持ち、DCB は置き先だけを決める（ojos/ai-packages-dev#222）**: `review-gate.yml` の実体は ai-playbook 側にある。この分離は `copilot-review.yml` と同じで、規範をここで再定義しない。
- **noreply 経路の許可は committer に縛る（ojos/ai-packages-dev#223）**: `is_github_authored()` は committer が `noreply@github.com` であることを必須とする。これにより GitHub 自身が作成したコミットに限定され、ローカルで作ったコミットには適用されない。許可リストへ個別 email を足して回る運用だと、メンバーが増えるたびに同じ穴が開く。
- **ドメイン一括許可は 2 形に限定する（ojos/ai-packages-dev#223）**: 解釈するのは `@example.com` と `*@example.com` だけ。任意の glob を許すと、設定ミスの `*` 1 文字で全 email が通り、検知層が黙って無効化される。`*` 単体はどちらの形にも当たらず、何も許可しない。
- **`@` を 2 つ持つ email を弾く（ojos/ai-packages-dev#223）**: 末尾一致だけで見ると `attacker@untrusted.com@example.com` が通る。git は author email を検証しないため、この形は実際に作れる。
- **正本と写しの追随漏れを機械で検知する（ojos/ai-packages-dev#227）**: `scripts/*.sh` は `bootstrap.sh` 内のヒアドキュメントが正本で、開発リポジトリ直下の `scripts/` はその写しである。両者の同期を検査する機構が無く、片方だけ直しても両方のテストが緑になっていた。実際に 2 件の追随漏れが積み上がっていた。検査は開発リポジトリ側の機構で、配布物には含まれない。

### 影響

- **`--with-copilot-review` を使う場合、規範パッケージは ai-playbook v0.1.8 以降が必要。** それより古い版を組み合わせると次で停止する。

  ```
  error: template not found in rules source: templates/review-gate.yml
         規範パッケージがこの版に必要な雛形を持っていません。
  ```

  このとき生成物は**途中まで書かれた状態で残る**。`--playbook-version v0.1.8`（以降）を指定すること。なお、この失敗の形は `review-gate.yml` に固有のものではなく、規範パッケージの雛形を要求する箇所すべてに共通する既存の挙動である。
- **`verify-commit-identity.sh` は挙動が変わる。** これまで NG になっていた GitHub 由来のコミット（committer が `noreply@github.com` かつ author が `<login>@users.noreply.github.com`）が通るようになる。ローカルの identity 適用漏れ（別アカウントの個人 email の混入）は従来どおり検知する。取り込み済みの利用側は再生成すること。
- **`load-project-env.sh` は挙動が変わる。** `.env` が生成先に無く、かつ git worktree から実行された場合に限り、メインの作業コピーの `.env` を読む。`PROJECT_ENV_FILE` を明示している場合は回り込まない。従来 `.env` を引けていた経路の挙動は変わらない。
- `setup-git-identity.sh` の変更は一時ファイル名のみで、生成物の挙動には影響しない。

## v0.8.1

### Summary
- **macOS ホストで `bootstrap.sh` が落ちる経路を塞いだ**（ojos/ai-packages-dev#218）。テンプレート引数を持たない `mktemp` / `mktemp -d` は GNU coreutils でしか動かず、BSD 系（macOS）ではテンプレートが必須で usage エラーになる。後方互換の不具合修正。
- **README の導入手順も同じ形で落ちていた**。取得と実行を一時ディレクトリで行う手順の 1 行目が素の `mktemp -d` だったため、macOS 利用者は `bootstrap.sh` を取得する前に落ちる。手順側も修正した。
- 生成物の挙動は変わらない。一時ファイル・一時ディレクトリの**作成先の名前**が変わるだけで、いずれも従来どおり実行後に削除される。

### Highlights

- **同一ファイルの中で分岐が片側だけだった（ojos/ai-packages-dev#218）**: `bootstrap.sh` は `stat` について「GNU coreutils は `-c`、BSD/macOS は `-f`」と分岐を持っており、macOS ホストでの実行は前提に入っていた。一方 `mktemp` は素のまま 8 箇所あり、macOS では**導入の最初の 1 回**で落ちる。Linux コンテナ内でしか動かさない開発では一度も表面化せず、利用者の側で初めて落ちる形になっていた。
- **書き忘れは目視では止まらなかった（ojos/ai-packages-dev#218）**: 開発リポジトリ全体では 6 ファイル 19 箇所まで積み上がっており、見つけたのは外部のレビュー。呼び出しを足すたびに人が思い出す形にせず、テンプレート無しの呼び出しを検出する検査を CI へ入れた（開発リポジトリ側の機構で、配布物には含まれない）。
- **検査は文書のコードブロックまで見る**: 実装だけを検査対象にしていたため、README の導入手順に残っていた同じ欠陥を最初の版では拾えなかった（リリース準備の段階で発見）。利用者がホストで実行するのは手順に書かれたコマンドであり、実装と同じ検査対象に置く。地の文は対象にしない（説明として `mktemp` と書く箇所があり、検査が文章の書き方に依存するため）。
- **作成先は `${TMPDIR:-/tmp}` を尊重する**: 従来どおり `TMPDIR` で作成先を変えられる。用途が読める接頭辞（`dcb-playbook` など）を付けたため、残骸が出た場合の出所も追える。

### 互換性

- 破壊的変更なし。CLI のオプション・生成物・生成物の配置はいずれも変わらない。

---

## v0.8.0

### Summary
- `--languages` に **`ruby` を第 6 の選択肢として追加**した（ojos/ai-packages-dev#206）。既存 5 言語（`node` / `go` / `python` / `php` / `rust`）と同等の生成・検査・診断・文書体験を提供する。後方互換の機能追加。
- 対応言語の README 追随漏れを機械で落とす**両方向の集合照合**を追加した。個別言語の取りこぼし検査は書いた言語しか守れず、次の言語追加で検査ごと足し忘れると素通りするため。

### Highlights

- **`--languages ruby` を追加（ojos/ai-packages-dev#206）**: `ghcr.io/devcontainers/features/ruby:1` を feature として配線し、`.gitignore` へ github/gitignore の `Ruby` テンプレートを取り込み、`doctor.sh` と生成物 `post-rebuild-check.sh` の検査対象に含める。VS Code の language server 拡張は選択時のみ `Shopify.ruby-lsp` を配線する（有料ティアを持たないため、`php` のような非配線扱いにはしない）。
- **`ruby` は feature 名と実行ファイル名が一致するため写像を持たない**: `rust` は feature が `rust` なのに実行ファイルが `cargo` / `rustc` に分かれるため `runtime_check_cmd` に `rust`→`cargo` の写像を置いている。`ruby` は一致するので分岐を追加しない。`runtime_check_cmd` は「例外だけを書く」形を保つ。
- **acceptance は `bundle exec rake` に委譲する**: ruby はテストフレームワークが Minitest / RSpec に分かれ、単一の慣習的コマンドが無い。`bundle exec rspec` や `bundle exec rake test` を既定にすると他方の流儀のプロジェクトで必ず失敗するため、`npm test` / `composer test` と同じく **プロジェクトの `Rakefile` の default タスクへ委譲**する形にした。マニフェスト判定は `Gemfile` の実在、ツール可用性の判定は `bundle`（`composer test` に対し `composer` を見る `php` と同型）。`Gemfile` が無ければ理由を出してスキップし、`Gemfile` があって `bundle` が無い場合は導入手順を添えて失敗させる（スキップと混同しない）。
- **対応言語の両方向照合を追加した**: 実装の受理値 `case` から対応言語の集合を生成し、README「言語サポート」節の箇条書きと差集合を両方向で突き合わせる。実装が受理するのに README に無い言語は「存在しない機能」になり、README にあるのに受理されない言語はコピペで即エラーになる。フラグ照合と同じ理由で片方向にしない（規範「一覧の複製は機械照合で担保する」）。
- **回帰テスト**: `tests/test-ruby-support.sh`（24 ケース）を追加。feature 配線・検査行・acceptance・gitignore ターゲット解決・拡張の条件配線・doctor 検出・入力検証を、いずれもネットワークに出ずに検証する。

### 互換性

- 破壊的変更なし。`--languages` へ選択肢が増えるだけで、既存 5 言語の挙動は変わらない。
- `ruby` を指定しない生成物には、ruby feature・`Ruby` gitignore テンプレート・`Shopify.ruby-lsp` 拡張・ruby の検査行と acceptance 行のいずれも入らない。

---

## v0.7.4

### Summary
- 生成される `scripts/loop-gate.sh` で、**push 済みブランチのときに第二意見が一度も差分を見ないまま `GATE_PASS` になる**経路を塞いだ（ojos/ai-packages-dev#198）。後方互換の不具合修正。
- v0.7.2 が塞いだ「ステージ済み差分が空のときの素通り」と同じ構造の残穴。当時は切り替え先の範囲が空になる場合を見ていなかった。

### Highlights

- **push 済みブランチでの素通りを塞ぐ（ojos/ai-packages-dev#198）**: 範囲解決は上流が設定されていれば `@{upstream}..HEAD` を組んでいたが、**push 済みのブランチでは上流と HEAD が同じコミットを指すため範囲の差分が空になる**。reviewer は空差分を「レビュー対象なし」として 0 で返すので、ゲート全体が「レビュー済み」として緑になる。実測では、修正を push した直後にゲートを回して `no diff to review (origin/<branch>..HEAD)` と `GATE_PASS` が並んで出ていた。範囲は「解決できたか」ではなく **「実際に差分があるか」** で選ぶよう改めた。上流との差分が空なら、既定ブランチの追跡枝（`origin/HEAD` / `origin/main` / `origin/master` の順に探索。名前は決め打ちしない）との**分岐点**まで戻し、ブランチ全体をレビュー対象にする。
- **起点を分岐点（merge-base）にした**: 従来の `base..HEAD` は 2 点間の比較で、既定ブランチ側に進んだコミットを「打ち消し」として差分へ混ぜる。ブランチが加えた変更だけを第二意見へ渡すため、起点を分岐点へ変更した。分岐点が求まらない（履歴が繋がっていない）場合は従来どおり追跡枝そのものを起点にする。
- **レビュー対象が本当に無い場合は明示して通過する**: 分岐点まで戻しても差分が無い状態（例: 既定ブランチを push した直後）は起こり得る。ここを一律 `GATE_FAIL` にすると、差分の無い状態でのゲート実行が落ちる。`[loop-gate] no reviewable diff; second opinion has nothing to review` を出したうえで通過させる。**黙って通すと偽の緑と区別が付かない**ため、出力での明示を伴わせる。対象が無いことが分かっている以上、reviewer は呼ばない（引数なしで呼ぶと空のステージ済み差分を見せることになり、v0.7.2 で塞いだ素通りへ戻る）。
- **空ツリーへの後退は remote が無い場合に限定した**: 起点が無いプロジェクト向けの最後の受け皿（空ツリーからの全体）は従来どおり残すが、上流や既定ブランチの追跡枝が存在する場合はそこへ落とさない。差分が無いことを理由にリポジトリ全体をレビュー対象へ広げてしまうためで、この場合は「レビュー対象なし」として扱う。
- **`gemini-review.sh` 側は変更していない**: 空差分での `exit 0` は、単体で使う場合の挙動として正しい（差分が無ければ何もしない）。ゲートとしての判断は `loop-gate.sh` が持つ、という責務分担を維持している。

### 影響

- 生成される `loop-gate.sh` の内容が変わる。既存の生成物は衝突ポリシー（`skip`/`overwrite`/`prompt`）により上書きされないため、再生成しない限り影響しない。
- **push 済みブランチでゲートを回すと、第二意見が実際に実行されるようになる**（従来は実行されずに通過していた）。ブランチ全体が対象になるため、実行時間と API 消費が増える。
- `LOOP_GATE_REVIEW_CMD` による差し替え・無効化の契約、ステージ済み差分があるときに引数を渡さない挙動、git 管理下にないプロジェクトでの挙動は変えていない。
- CLI の引数契約・生成される devcontainer の構成は変えていない。

---

## v0.7.3

### Summary
- README と実装の乖離を解消した（ojos/ai-packages-dev#170 / ojos/ai-packages-dev#171）。実装済みの CLI フラグ 3 件が未記載、実行前提コマンドが未記載、生成しないものを生成物として記載、doctor の検査項目と終了コードが未記載、といった記述誤りをまとめて直している。**生成物の挙動は変えていない。**
- `bootstrap.sh` / `doctor.sh` の usage が、開発リポジトリと公開配布物のどちらか一方でしか解決しないパスを示していた問題を修正した（ojos/ai-packages-dev#174 / ojos/ai-packages-dev#182）。
- `LICENSE`（MIT）と `CHANGELOG.md` を配布物へ追加した（ojos/ai-packages-dev#177）。あわせて README へ「配布専用リポジトリであり外部からの貢献は受け付けない」旨を明記した。
- 後方互換。

### Highlights

- **未記載だった CLI フラグを追加（ojos/ai-packages-dev#170）**: `--dry-run` / `--force` / `-h`・`--help` が README のどこにも無かった。とくに `--force` の欠落は影響が大きい。既定では既存ファイルを `skip (exists)` で温存するため、**再実行しても上書きされないことが README から読み取れなかった**。`--no-gitignore` / `--gitignore-targets` も使用例にしか現れていなかったのでオプション節へ昇格した。実行前提コマンド（`jq` / `perl` / `awk` / `sed` / `curl`、URL ソース時の `tar`）も一切書かれていなかったため追加した。不在時は即エラー終了する。
- **rust 対応の記述漏れ（ojos/ai-packages-dev#170）**: 対応言語の列挙 3 箇所から `rust` が抜けており、同一 README 内で矛盾していた（`--languages` の説明では rust を挙げている）。
- **生成物一覧を実装と一致させた（ojos/ai-packages-dev#171）**: 生成しない「README のセットアップ節更新」を削除し、常に生成される `scripts/install-ai-tools.sh` / `scripts/gemini-review.sh` と、規範配置時に作られる `.ai-playbook/VERSION` を追加した。`postCreateCommand` の記載値も実値と違っていた。
- **doctor 節の取りこぼし（ojos/ai-packages-dev#171）**: 「言語ランタイムと cloud CLI の可用性」しか説明していなかったが、実際は静的構造の存在検査・`devcontainer.json` の JSON 妥当性・**`${localEnv:` 混入の検出**・compose 参照先の実在・生成スクリプトの構文検査も行う。終了コードも未記載だった（FAIL>0 で 1、`--strict` かつ WARN>0 で **2**）。
- **リリース資産の説明（ojos/ai-packages-dev#171）**: 配布している `PACKAGE_ARCHIVE.tar.gz` と `RELEASE-MANIFEST.json` が README で一切説明されていなかった。あわせて `RELEASE-MANIFEST.json` の `assets` に、README が入手を案内する `bootstrap.sh` / `doctor.sh` が載っていなかった問題も直した。
- **usage のパス（ojos/ai-packages-dev#174 / ojos/ai-packages-dev#182）**: `doctor.sh` は固定パスで開発リポジトリの位置を出しており、公開配布物（リポジトリ直下）では解決しなかった。呼び出しに使われたパスをそのまま出す形へ変更した。`bootstrap.sh` も同様だが、usage ヒアドキュメント内に**リテラルの `$PWD`** が含まれるため、`doctor.sh` と同じく引用符を外すとヘルプの記述が壊れる。1 行目だけ分離して対処した。
- **`bootstrap.sh` の永続化に関する記述（ojos/ai-packages-dev#174）**: usage が「gh / cloud のログインは永続化されないのでリビルドのたびにやり直す必要がある」と述べていたが、実装は `gh` を常に永続化し、cloud も `--with-*` 選択時に永続化する。README のほうが正しく、usage が旧仕様のまま残っていた。
- **`CHANGELOG.md` を生成物へ持ち込まない（ojos/ai-packages-dev#177）**: 規範の配布ルートに `CHANGELOG.md` を置いたことで、`--with-playbook` の `*.md` 一括コピーが生成プロジェクトの `.ai-playbook/` へこれを取り込む状態になった。既存の `README.md` 除外と並べて除外した。

### 影響

- **生成物の内容が 1 点変わる**: `--with-playbook` で配置される `.ai-playbook/` に `CHANGELOG.md` が含まれなくなる（本来含むべきでないファイルの除外）。既存の生成物は衝突ポリシーにより上書きされないため、再生成しない限り影響しない。
- 配布物に `LICENSE` と `CHANGELOG.md` が加わる。`SHA256SUMS` の対象（`bootstrap.sh` / `doctor.sh`）は変わらない。
- `RELEASE-MANIFEST.json` の `assets` に `bootstrap.sh` / `doctor.sh` が加わる。
- CLI の引数契約・生成される devcontainer の構成は変えていない。

---

## v0.7.2

### Summary
- 生成される `scripts/loop-gate.sh` で、ステージ済み差分が空のときに第二意見が実質スキップされる経路を塞いだ（ojos/ai-packages-dev#152）。後方互換の不具合修正。
- **v0.7.1 の内容（ojos/ai-packages-dev#149）を含む。** v0.7.1 はタグを公開しないまま v0.7.2 へ統合したため、公開版としては v0.7.0 の次が v0.7.2 になる。

### Highlights
- **ステージ空での第二意見の素通りを塞ぐ（ojos/ai-packages-dev#152）**: `loop-gate.sh` の第 2 段は `gemini-review.sh` を引数なしで呼び、その既定対象はステージ済み差分だった。`gemini-review.sh` は差分が空だと「レビュー対象なし」として 0 を返すため、commit 後（ステージが空）にゲートを回すと**第二意見が実質スキップされたまま `GATE_PASS` が出ていた**。push 前ゲートとしては偽の緑になる。ステージが空のときだけ commit 済み範囲（`@{upstream}..HEAD` →無ければ `origin/HEAD` / `origin/main` / `origin/master` の順 →いずれも無ければ**空ツリー**からの全体）へ切り替える。最後の受け皿を `HEAD` にしてはならない。reviewer は範囲を `git diff` へ渡すため、`git diff HEAD` は「作業ツリー vs HEAD」となり、commit 直後はクリーンで差分が空になって素通りが復活する（`git log HEAD` が全履歴を指すのとは意味が違う）。空ツリーのハッシュはオブジェクト形式で異なるため定数を焼き込まず `git hash-object -t tree /dev/null` に計算させる。既定ブランチ名は決め打ちしない。ステージ済み差分があるときは従来どおり引数を渡さず reviewer の既定に委ねる（対象を上書きするとレビュー範囲が意図せず広がるため）。**git リポジトリでない場合・コミットが 0 件の場合も従来どおり引数なしで呼ぶ**（ここで落とすと、git 管理下にない生成直後のプロジェクトでゲートが使えなくなる）。
- 検出経路: ojos/ai-packages-dev#146 の実装中に判明し、第二意見（gemini-review）と Copilot も独立に同じ箇所を指摘した。

### 影響
- 生成される `loop-gate.sh` の内容が変わる。既存の生成物は衝突ポリシー（`skip`/`overwrite`/`prompt`）により上書きされないため、再生成しない限り影響しない。
- `LOOP_GATE_REVIEW_CMD` による差し替え・無効化の契約は変えていない。

---

## v0.7.1（未公開・v0.7.2 へ統合）

> この版はタグを公開しない。文書上の版として確定した直後に ojos/ai-packages-dev#152 が見つかったため、内容は v0.7.2 へ統合した。公開版としては v0.7.0 の次が v0.7.2 になる。記録として節を残す。

### Summary
- 生成される `scripts/verify-commit-identity.sh` で、許可 author email の解決からパス名展開（glob）を除去した（ojos/ai-packages-dev#149）。後方互換の不具合修正。

### Highlights
- **許可リストの glob 展開を除去（ojos/ai-packages-dev#149）**: 許可 email の配列代入がクォートなし（`ALLOWED_AUTHOR_EMAILS_ARR=($resolved)`）で、単語分割と同時にパス名展開も行っていた。`ALLOWED_AUTHOR_EMAILS` / `GIT_IDENTITY_EMAIL` に `*` や `?` が含まれると、許可リストが「検査対象リポジトリにどのファイルが存在するか」で変わる。実際に、ルートに author と同名のファイルを置くかどうかだけで `IDENTITY_PASS` と `IDENTITY_FAIL` が反転することを確認した。検知層の判定が検査対象の中身に左右されるのは、fail-closed 設計の意味を失わせる。`read -r -a` へ改め、単語分割だけを行わせる。here-string は末尾に改行を付けるため `set -e` 下でも `read` は 0 を返し、空文字なら空配列になって既存の fail-closed 検査に落ちる。回帰テストは「ファイルの有無で判定が変わらないこと」を検証する（片側だけでは、完全一致で落ちているのか展開が抑止されているのかを区別できないため）。

### 影響
- 生成される `verify-commit-identity.sh` の内容が変わる。既存の生成物は衝突ポリシー（`skip`/`overwrite`/`prompt`）により上書きされないため、再生成しない限り影響しない。
- 通常の email には glob メタ文字が含まれないため、既存の運用で挙動が変わることはない。

---

## v0.7.0

### Summary
- **破壊的変更**。生成物からホスト OS の資格情報を注入する経路（`remoteEnv` の `${localEnv:...}`）を全廃した。`remoteEnv` が運ぶのは `LOCAL_WORKSPACE_FOLDER` のみになり、認証はコンテナ内で行い、その状態を named volume に残す構造へ移行した（ojos/ai-packages-dev#129 / ojos/ai-packages-dev#130 / ojos/ai-packages-dev#131 / ojos/ai-packages-dev#132 / ojos/ai-packages-dev#133 / ojos/ai-packages-dev#141）。
- `--github-profiles` / `--gemini-key-env` を廃止し、`GITHUB_TOKEN_*` / `GITHUB_OWNER_*` / `GIT_AUTHOR_*_<PROFILE>` の環境変数契約を撤去した。`scripts/github-account-switch.sh` は生成しない。
- git identity の供給元をプロジェクト `.env` の `GIT_IDENTITY_NAME` / `GIT_IDENTITY_EMAIL` へ一本化し、雛形として `.env.example` を生成するようにした。
- 永続 volume を `gh` / `aws` / `gcloud` へ拡張し、所有権修復を `scripts/fix-mount-owner.sh` として独立させた。

### Highlights
- **remoteEnv からの資格情報撤去（ojos/ai-packages-dev#130）**: ホスト側と `.env` に別の値が入っていると、`.env` を読まない文脈でだけ黙ってホスト側が使われる。実際に、別アカウントの PAT が `git credential fill` から警告なく返り、別アカウントの API キーでクォータと課金が消費される事故が起きた。`remoteEnv` を `LOCAL_WORKSPACE_FOLDER` のみへ縮小し、廃止フラグは**黙殺せず**移行先を示して非ゼロ終了する（黙って無視すると「指定したのに注入されない」状態を作り、資格情報の所在をふたたび曖昧にするため）。
- **認証状態の永続化（ojos/ai-packages-dev#131）**: 注入を止めた以上、コンテナ内でのログインが唯一の認証手段になる。`gh` は github-cli feature が常時入るため `gh-storage` を常時定義し、`aws-storage` / `gcloud-storage` は `--with-aws` / `--with-gcp` に随伴する。生成する `post-rebuild-check.sh` は、定義した volume が**実際にマウントされているか**を `/proc/mounts` で検査する（定義しただけでマウントされない状態は、CLI が動くぶん気づきにくく、rebuild のたびに静かにログインが消える形で表面化するため）。
- **所有権修復の独立（ojos/ai-packages-dev#132）**: 空の named volume を初回マウントするとマウントポイントは `root:root` で作られ、`gh auth login` が Permission denied で落ちる。修復を `scripts/fix-mount-owner.sh` へ切り出し、`postCreateCommand` を `fix-mount-owner.sh && install-ai-tools.sh` の直列にした。`sudo -n` で非対話を保証し（`-n` が無いとパスワードを要求する環境で postCreate が入力待ちのまま固まる）、失敗しても WARN のうえ `exit 0` で CLI 導入まで到達する。ネストしたマウント先（`~/.config/gh` 等）の親は**非再帰**で直す（`~/.config` 配下の無関係な設定を巻き込まないため）。
- **供給元のコンテナ内集約（ojos/ai-packages-dev#133）**: `on-attach.sh` が接続ごとに `~/.docker/config.json` の `credsStore` / `credHelpers` を除去する（VS Code が接続のたびに書き込み、コンテナ内の docker がホスト OS のキーチェーンへ問い合わせるため）。git の `credential.helper` は「空 → `!gh auth git-credential`」の順で global に固定する。空文字がヘルパー一覧をリセットするため、`/etc/gitconfig` 側やエディタが注入したヘルパーが応答しなくなる。`setup-git-identity.sh --check` に、この固定順序と「local 設定を持たない一時リポジトリでの実効供給元が gh のみであること」の 2 検査を追加した。
- **`.env` への一本化（ojos/ai-packages-dev#133 / ojos/ai-packages-dev#141）**: identity は `.env` の `GIT_IDENTITY_NAME` / `GIT_IDENTITY_EMAIL` から解決する。`GIT_AUTHOR_NAME` / `GIT_AUTHOR_EMAIL` を使わないのは、それが git 自身の読む環境変数であり、環境に置くと local 未設定リポジトリでも identity が解決できて `user.useConfigOnly` の保護が無効になるため。理由は `.env.example` のコメントに残している。許可 author email の解決も、環境に値があっても必ず `.env` ローダーを通す（`.env` を唯一の供給元に保つため）。
- **doctor の secrets policy 反転（ojos/ai-packages-dev#132）**: 「`${localEnv:` 参照が**見つからない**と WARN」から「参照の**存在**を FAIL」へ改めた。撤去後の世界では、この参照はホスト資格情報の注入経路が復活したことを意味する。

### Breaking Changes
- **重大**: `--github-profiles` / `--gemini-key-env` を廃止した。指定すると非ゼロ終了で停止する。
- **重大**: `GITHUB_TOKEN_<PROFILE>` / `GITHUB_OWNER_<PROFILE>` / `GIT_AUTHOR_NAME_<PROFILE>` / `GIT_AUTHOR_EMAIL_<PROFILE>` の環境変数契約を撤去した。`scripts/github-account-switch.sh` は生成しない。
- **重大**: git identity の供給元が `.env` の `GIT_IDENTITY_NAME` / `GIT_IDENTITY_EMAIL` へ変わった。未設定のリポジトリでは `git commit` が exit 128 で止まる（設計どおり。黙って別名義で通るより止める）。
- トークン注入へ opt-in で戻す経路は用意しない。opt-in で穴を残せる構造そのものが、上記の事故を生んだ形であるため。

### 移行手順（既存の生成済みプロジェクト）
1. `.env` に `GEMINI_API_KEY` / `GIT_IDENTITY_NAME` / `GIT_IDENTITY_EMAIL` を設定する（雛形は再生成後の `.env.example`）。
2. `bootstrap.sh` を再実行して生成物を更新する（衝突ポリシーに従う。`--github-profiles` / `--gemini-key-env` は付けない）。
3. rebuild 後、コンテナ内で `gh auth login` を 1 度実行する（以後は `gh-storage` に残る）。`--with-aws` / `--with-gcp` を使う場合は `aws sso login` / `gcloud auth login` も同様。
4. ホスト側 VS Code に `dev.containers.dockerCredentialHelper: false` を設定する（README「ホスト側 VS Code に必要な設定」参照）。
5. ホスト OS の `GITHUB_TOKEN_*` / `GITHUB_OWNER_*` / `GIT_AUTHOR_*_<PROFILE>` は不要になる。

### Verification
- [ ] preflight 全通過（DCB テストスイート全ファイル green、README / 規範のリンク検査、バージョン不変性）
- [ ] 資産監査 OK（`RELEASE-MANIFEST.json` / `SHA256SUMS` / `PACKAGE_ARCHIVE.tar.gz` / `bootstrap.sh` / `doctor.sh`）

## v0.6.0

### Summary
- 開発補助として `tmux`（`ghcr.io/devcontainers-extra/features/tmux-apt-get:1`）を、`ripgrep` と同様に**常時同梱**するようにした（後方互換の機能追加。装備フラグ `--with-*` には追加しない。ojos/ai-packages-dev#115）。
- `--with-copilot` 選択時のみ、リモート最終ゲートの雛形を `.github/workflows/copilot-review.yml` として配置するようにした（後方互換の機能追加。雛形は規範パッケージが持ち、DCB は配置先だけを決める。ojos/ai-packages-dev#113）。
- 生成する `scripts/acceptance.sh` の既定を「**ルート直下にマニフェストが存在する対象だけ検証し、1 つも実行できなければ失敗する**」形へ変更した（軽微な破壊的変更。生成される既定内容が変わる。ojos/ai-packages-dev#112）。
- プロジェクト固有 `.env` を「ホスト由来の環境変数（`remoteEnv`）より後勝ちで上書き」で読み込む層を生成物へ追加した（後方互換の機能追加。ojos/ai-packages-dev#109）。
- 生成物に git identity ガード（適用・検証・CI の 3 層）を追加し、local 未設定リポジトリが黙って global へフォールバックしてコミットを通す経路を塞いだ（後方互換の機能追加。生成ファイルが増える。ojos/ai-packages-dev#108）。
- `--with-claude` 指定かつ規範導入時に、Claude Code 向け intake 起点スキルを `.claude/skills/intake/SKILL.md` へ配置するようにした（後方互換の機能追加。`--with-claude` 指定時に生成ファイルが 1 つ増える。ojos/ai-packages-dev#111）。

### Highlights
- **tmux の常時同梱（ojos/ai-packages-dev#115）**: `devcontainer.json` の features に `tmux` を追加した。既に開発補助として `ripgrep` を常時同梱している前例に整合させ、装備フラグ `--with-*`（cloud/AI ツール）へは入れない（`--mode` 廃止時に整理した `--with-*` の意味論を広げないため）。`devcontainers-extra` 名前空間は `ripgrep` で既に使用しており、新たな依存先は増えない。生成される `devcontainer.json` は妥当な JSON を保つ。
- **リモート最終ゲート雛形の配置（ojos/ai-packages-dev#113）**: `--with-copilot` を選び、かつ規範（playbook）を配置する構成のときだけ、規範パッケージの `templates/copilot-review.yml` を `.github/workflows/copilot-review.yml` へコピーする。`--with-copilot` 未指定、または規範を配置しない構成では置かない。DCB は内容を持たず配置先だけを決める（正本は規範パッケージ）。ワークフローは PR 作成時（`pull_request: types: [opened]`）に一度だけ Copilot へレビューを要求し、`synchronize` では再要求しないため「1 回だけ」を機構で保証する。フォークからの PR はスキップし、トークンは `COPILOT_REVIEW_TOKEN || GITHUB_TOKEN` へフォールバックする。既存ファイルには既存の衝突ポリシー（`skip`/`overwrite`/`prompt`）に従う。`--dry-run` の plan 出力にも copilot 選択時のみ含める。
- **acceptance.sh のマニフェスト検出ガード（ojos/ai-packages-dev#112）**: 生成する `scripts/acceptance.sh` を、選択言語ごとに**ルート直下のマニフェスト**（`node`→`package.json`、`go`→`go.mod`、`python`→`pyproject.toml`/`requirements.txt`、`php`→`composer.json`、`rust`→`Cargo.toml`）の実在を確認してから慣習的テストを実行する形へ変更した。マニフェストが無い言語は理由を出して**スキップ**し失敗させない。マニフェストはあるがツールが無い場合は**導入手順を添えて非 0 で終了**する（「スキップ」と「実行できなかった」を混同しない）。`ran_any` ガードで、1 つも検証を実行できなければ「受け入れ条件が未定義」と出力して**非 0 で終了**する（全スキップで誤って緑になり、検証していないことを合格と報告する事故を防ぐ）。スクリプト位置からルートを解決し、起動時 CWD に依存しない。従来はどこにマニフェストが無くても選択言語のテストコマンドを無条件に直列実行していたため、monorepo・未実装段階で生成直後が必ず「テストが無くて赤い」状態になっていた。新しい既定でも生成直後は赤いままだが、「受け入れ条件が未定義だと明示して落ちる」に変わり、失敗メッセージで受け入れ条件の定義を促せる。`verify.sh` は本 issue のスコープ外で変更しない。
- **プロジェクト `.env` の優先読み込み（ojos/ai-packages-dev#109）**: 中立名の `scripts/load-project-env.sh` を常時生成する。`.env` を **`source` せず** `KEY=VALUE` のみ安全にパースして `export` するため、任意コードを実行しない（壊れた `.env` が対話シェルの初期化ごと落とす事故を防ぐ）。CWD 非依存でスクリプト位置から `.env` を解決し、bash / zsh の双方で動作する。CRLF・`export KEY=VALUE`・`KEY = VALUE`・クォート囲みを吸収し、冪等。`PROJECT_ENV_FILE` で対象ファイルを差し替え可能。生成される `scripts/on-attach.sh` が `~/.bashrc` / `~/.zshrc` へマーカー付きで**冪等に**注入し、対話シェルから起動する CLI（`gemini` 等）にも `.env` の値を効かせる（rc 不在なら `touch` で作成、参照は絶対パス）。
- **git identity ガード（ojos/ai-packages-dev#108）**: `scripts/setup-git-identity.sh` を追加。global の `user.name` / `user.email` を削除して `user.useConfigOnly=true` を立て、local 未設定リポジトリでの `git commit` を exit 128 で停止させる。当リポジトリの local には先頭 profile（`--github-profiles` の 1 つ目）の `GIT_AUTHOR_*_<PROFILE>` を適用する。冪等で `--check` が状態を検証し、`credential.helper` は壊さない。`scripts/on-attach.sh` が毎接続で再適用する（VS Code の `copyGitConfig` がリビルドごとに `~/.gitconfig` を再生成するため）。**失敗しても on-attach 全体は落とさず**、WARN と手動確認コマンドの案内に留める。
- **git identity 検証（ojos/ai-packages-dev#108）**: `scripts/verify-commit-identity.sh` を追加。コミット履歴の identity を **email のみ**で検証する（CI と手元で共用）。許可 author email は環境変数 `ALLOWED_AUTHOR_EMAILS` を最優先し、無ければ先頭 profile の `GIT_AUTHOR_EMAIL_<PROFILE>` へフォールバック。どちらも無ければ fail-closed。committer は `noreply@github.com`、Co-Authored-By は加えて `noreply@anthropic.com` を許可。`.github/workflows/identity-guard.yml` を追加し、`pull_request` と `push`(main) の 2 系統で検証を強制する。許可 author email は生成物に焼き込まず、利用側のリポジトリ変数 `ALLOWED_AUTHOR_EMAILS`（`vars.ALLOWED_AUTHOR_EMAILS`）から渡す。判定はシェル側にあり、ワークフローは呼ぶだけ。利用側は GitHub の **Settings → Secrets and variables → Actions → Variables** に `ALLOWED_AUTHOR_EMAILS` を設定する（README「Git identity ガード」参照）。
- **Claude intake 起点スキルの配置（ojos/ai-packages-dev#111）**: `--with-claude` を選び、かつ規範（ai-playbook）を導入する場合に限り、`.claude/skills/intake/SKILL.md` を配置する。雛形の内容は DCB では持たず、規範パッケージの `templates/claude-skill-intake.md` を `require_playbook_template` で要求して置くだけにする（内容の正本を 1 つに保ち、規範側の更新に追随させる）。Claude Code の機構がスキル定義ファイル名を `SKILL.md` に固定するため、`lower-kebab-case` の雛形名から改名して配置する。`--with-claude` を指定しない、または規範を導入しない場合は `.claude/` を生成しない。雛形を持たない古い ai-playbook をソースにすると、書き込み前に `require_playbook_template` が失敗する。配置は既存の衝突ポリシー（`--playbook-conflict-policy`）に従い、`--dry-run` の plan 出力にも含める。

### Breaking Changes
- **軽微（ojos/ai-packages-dev#112）**: 生成される `scripts/acceptance.sh` の既定内容が変わる。既存の生成物は衝突ポリシー（`skip`/`overwrite`/`prompt`）により上書きされないため、再生成しない限り影響しない。
- その他はなし（後方互換の機能追加）。git identity ガードで生成ファイルが 3 つ増え、`--with-claude` 指定時にさらに `.claude/skills/intake/SKILL.md` が 1 つ増える。既存の生成物に対しては既存の衝突ポリシー（`skip`/`overwrite`/`prompt`）に従う。

### Verification
- [ ] preflight 全通過（DCB テストスイート、`test-env-loader.sh` / `test-git-identity.sh` を含む全ファイル green、README / 規範のリンク検査、バージョン不変性）
- [ ] 資産監査 OK（`RELEASE-MANIFEST.json` / `SHA256SUMS` / `PACKAGE_ARCHIVE.tar.gz` / `bootstrap.sh` / `doctor.sh`）

## v0.5.1

### Summary
- 取り込んだ ai-playbook の出所を、生成先の `.ai-playbook/VERSION` に記録するようにした（後方互換の機能追加）。

### Highlights
- `--playbook-version` などでバージョンを指定しても、生成後の環境に「どの版の playbook を取り込んだか」の on-disk 証跡が残らず、後から照合できなかった（devcontainer 自己診断 F-7）。
- 規範を配置するとき `.ai-playbook/VERSION` を生成し、`version`（`--playbook-version` のタグ。未指定は `(unspecified)`）と `source`（解決済みソース。隣接チェックアウトは `<adjacent checkout>`）を `key=value` で記録する。`--dry-run` の plan 出力にも含める。
- 書き込みは規範ファイルと同じ衝突ポリシー（`skip`/`overwrite`/`prompt`）に従う（`apply_file_with_policy` を再利用）。既存を `skip` した on-disk 規範を温存したまま `VERSION` だけ無条件上書きすると、記録が実際の規範とずれて出所が嘘になるため。

### Breaking Changes
- なし（後方互換の機能追加）。

### Verification
- [ ] preflight 全通過（DCB テストスイート、README / 規範のリンク検査、バージョン不変性）
- [ ] 資産監査 OK（`RELEASE-MANIFEST.json` / `SHA256SUMS` / `PACKAGE_ARCHIVE.tar.gz` / `bootstrap.sh` / `doctor.sh`）

## v0.5.0

### Summary
- Claude 認証を OAuth トークン注入から作業前 `/login` 既定へ変更（**破壊的変更**）。
- AI ツール永続 volume の所有権を修正し、`/login` 不能を解消（バグ修正）。

### Breaking Changes
- `--with-claude` の生成物で `remoteEnv` へ `CLAUDE_CODE_OAUTH_TOKEN` を**無条件注入する挙動を廃止**。OAuth トークンは権限スコープが限定されフルスペック操作が許可されないため、作業前に `/login` する方式を既定にした。`~/.claude` は named volume で永続するため、一度 `/login` すればリビルドをまたいで有効。
- `--claude-token-env` フラグ / `CLAUDE_TOKEN_ENV` 変数 / `__CLAUDE_TOKEN_ENV__` の sed 置換を除去。
- CI 等でトークン運用が必要な場合は、生成された `.devcontainer/devcontainer.json` の `remoteEnv` へ手動で 1 行追記する（手順は README に記載）。

### Fixes
- AI ツール用の永続 named volume（`claude-storage:/home/vscode/.claude` 等）を空の状態で初回マウントすると、マウントポイントを Docker デーモン（root）が `root:root` で作成するため、`remoteUser`（vscode）が書き込めず AI CLI のログイン/設定書き込みが失敗していた。
- `postCreateCommand`（`install-ai-tools.sh`）に `fix_owner` を追加し、選択した AI ツールの設定ディレクトリの所有者が現ユーザーと異なる場合のみ `sudo chown -R` で復旧する（冪等）。`sudo` 不在・`chown` 失敗のいずれも `set -euo pipefail` 下で postCreate を止めず、WARN を出して CLI 導入まで到達させる。

### Verification
- [ ] preflight 全通過（DCB テストスイート、README / 規範のリンク検査、バージョン不変性）
- [ ] 資産監査 OK（`RELEASE-MANIFEST.json` / `SHA256SUMS` / `PACKAGE_ARCHIVE.tar.gz` / `bootstrap.sh` / `doctor.sh`）

## v0.4.2

### Summary
- playbook 取得失敗時に devcontainer を部分生成してから遅延失敗する不具合を修正（バグ修正）。

### Fixes
- 存在しないタグ（例: `--playbook-version` の `v` 抜け）や URL の 404、壊れたアーカイブでも、従来は devcontainer を全ファイル書き込んでから `no rule files found` で失敗していた。README が約束する「取得元が解決できなければ 1 つも書き込まず終了」に反していた。
- 原因は `detect_playbook_dir` が `curl` / `tar` の失敗を明示検査せず `set -e` に依存していたが、`PLAYBOOK_DIR="$(...)"` の代入コマンド置換では `set -e` が発火しないこと。`curl` / `tar` の明示検査、代入コマンド置換の終了コード捕捉、規範 0 件の書き込み前検査で**アトミックに停止**するよう修正。
- `--playbook-version` 使用時の取得失敗には `v` 接頭辞のヒント（例: `v0.1.1`）を表示。

### Verification
- [ ] preflight 全通過（DCB テストスイート、README / 規範のリンク検査、バージョン不変性）
- [ ] 資産監査 OK（`RELEASE-MANIFEST.json` / `SHA256SUMS` / `PACKAGE_ARCHIVE.tar.gz` / `bootstrap.sh` / `doctor.sh`）

## v0.4.1

### Summary
- ai-playbook ソース指定の使い勝手を改善（後方互換の追加）。

### Highlights
- `--playbook-version <tag>` を追加。既定ソース `ojos/ai-playbook` のタグ tarball（`.../archive/refs/tags/<tag>.tar.gz`）へ内部展開し、長い URL を打たずに版だけで指定できる。`--playbook-from` とは相互排他。
- ソース（`--playbook-from` / `--playbook-version`）を指定した場合、`--with-playbook` を省略しても規範を配置する。判定順は「明示 opt-out（`--without-playbook`）> 明示 opt-in（`--with-playbook`）> ソース指定あり」。

### Breaking Changes
- なし。`--playbook-from` 単体は従来「無視」だったが「配置」になる（silent no-op の解消）。`--without-playbook` は最優先で従来どおり配置しない。

### Verification
- [ ] preflight 全通過（DCB テストスイート、README / 規範のリンク検査、バージョン不変性）
- [ ] 資産監査 OK（`RELEASE-MANIFEST.json` / `SHA256SUMS` / `PACKAGE_ARCHIVE.tar.gz` / `bootstrap.sh` / `doctor.sh`）

## v0.4.0

### Summary
- `--mode <minimal|standard|full>` を廃止し、装備を `--with-*` フラグへ分解した**破壊的変更**。

### Highlights
- `--mode` 廃止（未知オプションとしてエラー）。3 mode 別テンプレを 1 つのパラメータ化テンプレへ集約し重複を解消。
- docker のリッチさ（buildx + compose-switch）を全生成物で標準化。
- cloud: `--with-aws` / `--with-gcp` を追加。Terraform はいずれかの cloud 指定時に暗黙同梱（両指定でも 1 回、cloud 無指定なら無し）。
- AI ツール: `--with-claude` / `--with-gemini` / `--with-copilot` を追加。トークンによる自動導入を廃止し明示 opt-in のみ。各フラグは CLI + VS Code 拡張 + 設定の永続化（compose named volume）を同型で実施。
- AI 認証の永続化を mode 非依存化（旧 full 限定を撤廃）。
- `doctor.sh` に cloud CLI（aws/gcloud/terraform）可用性検査を追加。

### Breaking Changes
- **`--mode` を削除**。旧 `--mode standard` は概ね `--with-aws`、旧 `--mode full` は `--with-aws --with-gcp --with-claude --with-gemini --with-copilot` に相当。移行対応表は DCB README「mode オプションからの移行」を参照。
- AI CLI（claude/gemini）の**トークンによる自動導入を廃止**。今後は `--with-<ai>` の明示指定が必要。
- docker のリッチさが全生成物で標準になったため、旧 `minimal` 相当でも buildx 等が入る。

### 予定（未実装）
- `--with-codex`（OpenAI Codex）/ `--with-sakura`（さくらのクラウド）/ `--with-cloudflare`（Cloudflare）は拡張点の枠のみ。

### Verification
- [ ] preflight 全通過（DCB テストスイート、README / 規範のリンク検査、バージョン不変性）
- [ ] 資産監査 OK（`RELEASE-MANIFEST.json` / `SHA256SUMS` / `PACKAGE_ARCHIVE.tar.gz` / `bootstrap.sh` / `doctor.sh`）

## v0.3.1

### Summary
- ループコーディング支援の実行体を生成に追加。全モードで生成し、外部パッケージの導入を前提にせず単体で動作する。

### Highlights
- 生成物に `scripts/verify.sh`（受け入れ条件を非対話実行し一意な通過信号 `VERIFY_PASS` を返す接地信号）、`scripts/acceptance.sh`（プロジェクト所有の受け入れ条件。選択言語の慣習的テストコマンドを既定配置）、`scripts/loop-gate.sh`（push / PR 前のローカル事前ゲート。`verify.sh` と任意の第二意見レビューを直列化）を追加。
- `doctor.sh` がループスクリプト 3 種の存在・構文・実行権限を検査。
- README に「ループコーディング支援」節を追加。ワークフローの正本は ai-playbook の `loop-workflow.md` / 解説は `loop-coding-guide.md` を参照。`--with-playbook` の取得元を ai-playbook `v0.1.1` へ更新。

### Breaking Changes
- なし（後方互換の機能追加）。

### Verification
- [ ] preflight 全通過（DCB テストスイート、README / 規範のリンク検査、バージョン不変性）
- [ ] 資産監査 OK（`RELEASE-MANIFEST.json` / `SHA256SUMS` / `PACKAGE_ARCHIVE.tar.gz` / `bootstrap.sh` / `doctor.sh`）

## v0.1.0

### Summary
- 配布リポジトリをクリーンな履歴で再作成した、新世代の初回リリース。

### Highlights
- 機能は旧世代最終版（v0.3.1）の内容をすべて含む: `--with-playbook --playbook-from <ai-playbook タグ tarball>`、`.ai-playbook/` 配置、GitHub archive 形式の構造検出、`.env` 自動読み込み、アカウント自動選択フォールバック。
- 履歴・タグ・Release を新規に作成。コミット作者情報は `Ido <ido@ojos.jp>` に統一。

### Breaking Changes
- 旧世代のタグ（v0.1.15〜v0.3.1）と Release の固定 URL は無効。取得手順の `TAG` を `v0.1.0` へ更新する。

### Verification
- [x] preflight 全通過（DCB テストスイート、README / 規範のリンク検査、バージョン不変性）
- [x] 資産監査 OK（`RELEASE-MANIFEST.json` / `SHA256SUMS` / `PACKAGE_ARCHIVE.tar.gz` / `bootstrap.sh` / `doctor.sh`）
- [x] コミット作者・コントリビューターが単一 identity であることを確認
